# Igore
Desgin, Control, and Simulation of Hebi Robotics' Igor robot using ROS-Gazebo.
