#pragma once

#include <ros/ros.h>
#include <std_srvs/Empty.h>
#include <tf_conversions/tf_eigen.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Point.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/TransformStamped.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <geometry_msgs/Quaternion.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <tf2_ros/transform_listener.h>
#include <tf/transform_listener.h>
#include <tf2_ros/buffer.h>
#include <Eigen/Dense>
#include <math.h>
#include <boost/bind.hpp>
#include <pthread.h>
#include <std_msgs/Float64.h>
#include <geometry_msgs/PointStamped.h>

#define M_PI 3.14159265358979323846

class igor_pid_control
{
private:
    ros::NodeHandle nh_; // creating ROS NodeHandle

    typedef message_filters::sync_policies::ApproximateTime<
        sensor_msgs::Imu, sensor_msgs::JointState, geometry_msgs::PointStamped> SyncPolicy;
    
    message_filters::Subscriber<sensor_msgs::Imu>* body_imu_sub_;  
    message_filters::Subscriber<sensor_msgs::JointState>* joint_states_sub_; 
    message_filters::Subscriber<geometry_msgs::PointStamped>* CoG_sub_;

    message_filters::Synchronizer<SyncPolicy>* sync_;

    ros::Publisher  Lwheel_pub; // creating ROS publisher
    ros::Publisher  Rwheel_pub; 
    ros::Publisher  Lknee_pub; 
    ros::Publisher  Rknee_pub; 
    ros::Publisher  Lhip_pub; 
    ros::Publisher  Rhip_pub; 

    ros::Subscriber sub_command_velocity;

    std_msgs::Float64 tqr_Lwheel;
    std_msgs::Float64 tqr_Rwheel;
    std_msgs::Float64 position_Lhip;
    std_msgs::Float64 position_Rhip;
    std_msgs::Float64 position_Lknee;
    std_msgs::Float64 position_Rknee;

    geometry_msgs::Quaternion  igor_orient;  // Quaternion type variable
    tf::Quaternion quat;
    geometry_msgs::Point CoG_Position;
    
    geometry_msgs::TransformStamped leftLegTransformStamped;
    geometry_msgs::TransformStamped rightLegTransformStamped;

    tf2_ros::TransformBroadcaster br;
    geometry_msgs::TransformStamped transform_;

    tf2_ros::Buffer leftLegTfBuffer;
    tf2_ros::TransformListener leftLegTfListener{leftLegTfBuffer};
    tf2_ros::Buffer rightLegTfBuffer;
    tf2_ros::TransformListener rightLegTfListener{rightLegTfBuffer};
    
    // synchronize subscribers
    void combineCallback(const sensor_msgs::Imu::ConstPtr &msg1, 
                         const sensor_msgs::JointState::ConstPtr &msg2, 
                         const geometry_msgs::PointStamped::ConstPtr &msg3);
    // subscribe keyboard velocity
    void command_velocity_callback(const geometry_msgs::Twist::ConstPtr &msg);  //

    Eigen::Vector3d rightLegTranslation;
    Eigen::Vector3d leftLegTranslation;
    Eigen::Vector3d groundPoint;
    Eigen::Vector3d CoM_vec = {-0.019, 0, -0.183};
    Eigen::Vector3d CoM_line;
    Eigen::Matrix3d pitchRotEigen;

    tf::Matrix3x3 pitchRotation;
    

public:
    igor_pid_control(ros::NodeHandle* nodehandle); // constructor
    ~igor_pid_control(); // destructor
    void pidController(void);

    double HZ = 100;
    float dt = 0.01;
  
    // float leanP =  17.5, leanI = 0.3, leanD = 0.006;
    // float velP = 0.115, velI = 0.020, velD = 0.0004;
    float velP = 0.103847, velI = 0.0, velD = 0.0;
    float leanP =  22.3446, leanI = 0., leanD = 0.0170027;
    float wheelRotationP = 0.1, wheelRotationI = 0.001;

    const float robot_mass = 7.21 + 0.83 + (0.36 + 0.39 + 0.5 + 0.37 + 0.46 + 0.35) * 2.0;

    float current_Lhip_position = 0.0;
    float current_Lknee_position = 0.0;
    float current_Rhip_position = 0.0;
    float current_Rknee_position = 0.0;

    double roll = 0; 
    double pitch = 0; 
    double yaw = 0.0;
    float leanAngle_dot = 0.0;

    float leanAngle = 0; 
    float CoM_height = 0.555;

    
    // velocity
    float L_wheel_angular_vel = 0.0;
    float R_wheel_angular_vel = 0.0;
    float L_wheel_angular_vel_last = 0.0;
    float R_wheel_angular_vel_last = 0.0;
    // acceleration
    float L_wheel_angular_accel = 0.0;
    float R_wheel_angular_accel = 0.0;

    const float r_wheel = 0.100;
    const float l_wheel = 0.43;

    float robot_x = 0.0;
    float robot_y = 0.0;
    float robot_theta = 0.0;

    float current_linear_vel = 0.0;
    float current_angular_vel = 0.0;
    float current_coupled_linear_vel = 0.0;
    float last_linear_vel = 0.0;
    float last_angular_vel = 0.0;
    float last_coupled_linear_vel = 0.0;

    float linear_accel = 0.0;

    float command_linear_velocity = 0.0;
    float command_angular_velocity = 0.0;
    float command_linear_velocity_last = 0.0;
    float command_angular_velocity_last = 0.0;
    float command_linear_accel = 0.0;
    float command_lean_angle = 0.0;
    float command_vel_Lwheel = 0.0;
    float command_vel_Rwheel = 0.0;
    
    float error_linear_vel = 0.0;
    float error_linear_vel_last = 0.0;
    float error_linear_vel_cumulative = 0.0;
    float error_linear_vel_differential = 0.0;
    
    float error_lean_angle = 0.0;
    float error_lean_angle_last = 0.0;
    float error_lean_angle_cumulative = 0.0;
    float error_lean_angle_differential = 0.0;

    float error_angular_vel = 0.0;

    float lean_feedforward = 0.0;
    float linear_vel_feedforward = 0.0;
    float angular_vel_feedforward = 0.0;

    float effort_balance = 0.0;
    float effort_vel_Lwheel = 0.0;
    float effort_vel_Rwheel = 0.0;

    float error_vel_Lwheel = 0.0;
    float error_vel_Lwheel_accumlative = 0.0;
    float error_vel_Rwheel = 0.0;
    float error_vel_Rwheel_accumlative = 0.0;

    float cal_linear_velocity = 0.0;
    float cal_angular_velocity = 0.0;

    double current_time=0.0;
    double last_time=0.0;
    
    int count = 0;
    int lean_count = 0;

};