#pragma once

#include <cstdio>
#include <time.h>
#include <vector>
#include <queue> // std::queue
#include <deque> // std::deque
#include <thread>
#include <mutex>
#include "tf/transform_datatypes.h"
#include "geometry_msgs/Vector3.h"
#include "std_msgs/Header.h"
#include "std_msgs/Float64.h"
#include <std_msgs/Float32MultiArray.h>
#include "std_msgs/Bool.h"
#include <Eigen/Dense>
#include <math.h>
#include <ros/service.h>
#include <std_srvs/Empty.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <tf_conversions/tf_eigen.h>
#include <tf/transform_broadcaster.h>
#include <tf2_ros/transform_listener.h>
#include <tf/transform_listener.h>
#include <tf2_ros/buffer.h>
#include <geometry_msgs/TransformStamped.h>
#include "rosgraph_msgs/Clock.h"


#define M_PI 3.14159265358979323846


class igor_knee_control
{

private:
    float lqr_right_trq = 0;
    float lqr_left_trq = 0;

  
    std_msgs::Float64 lqr_trq_r;
    std_msgs::Float64 lqr_trq_l;
    std_msgs::Float64 CT_trq_r;
    std_msgs::Float64 CT_trq_l;
    std_msgs::Float64 trq_r;
    std_msgs::Float64 trq_l;
    std_msgs::Float64 knee_ref;
    std_msgs::Float64 hip_ref;

    float dwa_linear_velocity = 0.0;
    float dwa_angular_velocity = 0.0;
    float translation_distance = 0.0;
    float rotation_angle = 0.0;
    bool _reset = false;

    std::mutex mylock;
    
    ros::NodeHandle nh_; // creating ROS NodeHandle

    ros::Subscriber sub_command_velocity;
    ros::Subscriber sub_command_position;
    ros::Subscriber sub_states;
    ros::Subscriber clk_subscriber;
    
    ros::Publisher  Lwheel_pub; // creating ROS publisher
    ros::Publisher  Rwheel_pub; // creating ROS publisher
    ros::Publisher  Lknee_pub; // creating ROS publisher
    ros::Publisher  Rknee_pub; // creating ROS publisher
    ros::Publisher  Lhip_pub; // creating ROS publisher
    ros::Publisher  Rhip_pub; // creating ROS publisher
    
   
    void command_velocity_callback(const geometry_msgs::Twist::ConstPtr &msg);
    void lqr_controller(Eigen::VectorXf eig_vec);
    void CT_controller(Eigen::VectorXf eig_vec);
    void ff_fb_controller();
    void ref_update();
    void clk_callback(const rosgraph_msgs::Clock::ConstPtr &msg);
    void statesCallback(const std_msgs::Float32MultiArray::ConstPtr &msg);

    Eigen::MatrixXf k_r = Eigen::MatrixXf(1,6); // declaring 1X6 Eigen matrix of datatype float
    Eigen::MatrixXf k_l = Eigen::MatrixXf(1,6); // declaring 1X6 Eigen matrix of datatype float
    //Eigen::MatrixXf k_k = Eigen::MatrixXf(1,8); // declaring 1X6 Eigen matrix of datatype float
    Eigen::VectorXf igor_state = Eigen::VectorXf(6); // declaring 6x1 Eigen vector of datatype float;
    Eigen::VectorXf igor_linear_vel = Eigen::VectorXf(500); 
    Eigen::VectorXf igor_angular_vel = Eigen::VectorXf(500);
    int counts = 0;
    float CoM_height = 0;
    Eigen::VectorXf ref_state = Eigen::VectorXf(6);
    //Eigen::Vector3d robot_center_pos;
 
    Eigen::MatrixXd M_h = Eigen::MatrixXd(3,3);
    Eigen::Vector3d H_h;
    Eigen::MatrixXd V_h = Eigen::MatrixXd(3,3);
    Eigen::Vector3d G_h;
    Eigen::MatrixXd E_h_inv = Eigen::MatrixXd(2,3);
    Eigen::Vector3d Ep;
    Eigen::Vector3d Ev;
    Eigen::Vector3d velocities;
    Eigen::MatrixXd Kp = Eigen::MatrixXd(3,3);
    Eigen::MatrixXd Kv = Eigen::MatrixXd(3,3);

    // CT gains for ff_fb_controller
    // float Kp1 = -7*1.3; // Linear postion gain
    // float Kp2 = -50*0.5; // Yaw gain
    // float Kp3 = -95*0.6;//-105; // Pitch gain
    // float Kv1 = -5*0.53; // Linear velocity gain
    // float Kv2 = -10*0.3; // Yaw speed gain
    // float Kv3 = -20*0.65; // Pitch speed gain

    float Kp1 = -6.3; // Linear postion gain
    float Kp2 = -60; // Yaw gain
    float Kp3 = -95;//-105; // Pitch gain
    float Kv1 = -4; // Linear velocity gain
    float Kv2 = -10; // Yaw speed gain
    float Kv3 = -20; // Pitch speed gain
    
    Eigen::Vector3d feedbck;
    Eigen::Vector2d output_trq;

    ros::Time sim_time;
    ros::ServiceClient client;
    std_srvs::Empty srv;

public:

    igor_knee_control(ros::NodeHandle* nodehandle); // constructor
    ~igor_knee_control(); // destructor

}; //end of class
