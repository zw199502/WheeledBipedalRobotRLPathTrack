#pragma once

#include <cstdio>
#include "ros/ros.h"
#include "sensor_msgs/Imu.h"
#include "sensor_msgs/JointState.h"
#include <vector>
#include <queue> // std::queue
#include <deque> // std::deque
#include "geometry_msgs/Quaternion.h"
#include "tf/transform_datatypes.h"
#include "geometry_msgs/Vector3.h"
#include "std_msgs/Header.h"
#include "std_msgs/Float64.h"
#include <std_msgs/Float32MultiArray.h>
#include "std_msgs/Bool.h"
#include <Eigen/Dense>
#include <math.h>
#include "nav_msgs/Odometry.h"
#include "geometry_msgs/PoseWithCovariance.h"
#include "geometry_msgs/TwistWithCovariance.h"
#include "geometry_msgs/Point.h"
#include "geometry_msgs/PointStamped.h"
#include "geometry_msgs/Twist.h"
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <ros/service.h>
#include <std_srvs/Empty.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <tf_conversions/tf_eigen.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_broadcaster.h>
#include <tf2_ros/transform_listener.h>
#include <tf/transform_listener.h>
#include <tf2_ros/buffer.h>
#include <geometry_msgs/TransformStamped.h>
#include <visualization_msgs/Marker.h>
#include "rosgraph_msgs/Clock.h"
#include <tf2_ros/transform_broadcaster.h>


#include <gazebo_msgs/GetModelState.h>
#include <gazebo_msgs/GetModelStateRequest.h>
#include <gazebo_msgs/GetModelStateResponse.h>


#include "gram_savitzky_golay.h" //gram_savitzky_golay lib

#include <boost/circular_buffer.hpp>


#define M_PI 3.14159265358979323846

class igor_states_no_sensor{

private:

    typedef message_filters::sync_policies::ApproximateTime<
        sensor_msgs::Imu,sensor_msgs::Imu,sensor_msgs::Imu,
        sensor_msgs::JointState,geometry_msgs::PointStamped> SyncPolicy;
    
    message_filters::Subscriber<sensor_msgs::Imu>* body_imu_sub_;   // topic1 input
    message_filters::Subscriber<sensor_msgs::Imu>* L_wheel_imu_sub_;   // topic2 input
    message_filters::Subscriber<sensor_msgs::Imu>* R_wheel_imu_sub_;   // topic3 input
    message_filters::Subscriber<sensor_msgs::JointState>* joint_states_sub_;   // topic4 input
    message_filters::Subscriber<geometry_msgs::PointStamped>* CoG_sub_;   // topic5 input
    message_filters::Synchronizer<SyncPolicy>* sync_;

    ros::ServiceClient get_state_service;
    gazebo_msgs::GetModelStateResponse objstate;
    gazebo_msgs::GetModelStateRequest model;

    geometry_msgs::Quaternion  igor_orient;  // Quaternion type variable
    geometry_msgs::Point CoG_Position;
    
    geometry_msgs::TransformStamped leftLegTransformStamped;
    geometry_msgs::TransformStamped rightLegTransformStamped;

    tf2_ros::TransformBroadcaster br1;
    geometry_msgs::TransformStamped transform1;
    tf2_ros::TransformBroadcaster br2;
    geometry_msgs::TransformStamped transform2;

    tf2_ros::Buffer leftLegTfBuffer;
    tf2_ros::TransformListener leftLegTfListener{leftLegTfBuffer};
    tf2_ros::Buffer rightLegTfBuffer;
    tf2_ros::TransformListener rightLegTfListener{rightLegTfBuffer};
    
    double wheel_odom_x = 0;
    double wheel_odom_y = 0;
    double wheel_odom_yaw = 0;
    double sensor_time_last = 0;
    double sensor_time_current = 0;
    ros::Time odom_baseLink;
    ros::Time map_odom;
    double odom_orientation_x = 0;
    double odom_orientation_y = 0;
    double odom_orientation_z = 0;
    double odom_orientation_w = 0;
 

    double roll = 0; 
    double pitch = 0; 
    double yaw = 0.0;
    
    std_msgs::Float32MultiArray pub_states;
    std_msgs::Float32MultiArray pub_general_state;
    Eigen::VectorXf igor_state = Eigen::VectorXf(6); // declaring 6x1 Eigen vector of datatype float;

    float CoG_angle = 0; 
    float leanAngle = 0; 
    float CoM_height = 0;

    float CoG_angle_filtered = 0;

    float L_wheel_pitch_angul = 0.0;
    float R_wheel_pitch_angul = 0.0;
    float r_wheel = 0.1016;
    float robot_x = 0.0;
    float robot_y = 0.0;
    double current_time=0.0;
    double last_time=0.0;
    float dt = 0.0;
    
    tf::Quaternion quat;

    ros::NodeHandle nh_; // creating ROS NodeHandle

    ros::Publisher  igor_general_state_publisher;
    ros::Publisher  igor_state_publisher;
    
    void combineCallback(const sensor_msgs::Imu::ConstPtr &msg1, 
        const sensor_msgs::Imu::ConstPtr &msg2, const sensor_msgs::Imu::ConstPtr &msg3,
        const sensor_msgs::JointState::ConstPtr &msg4, const geometry_msgs::PointStamped::ConstPtr &msg5);

    Eigen::Vector3d rightLegTranslation;
    Eigen::Vector3d leftLegTranslation;
    Eigen::Vector3d groundPoint;
    Eigen::Vector3d CoM_vec;
    Eigen::Vector3d CoM_line;
    Eigen::Matrix3d pitchRotEigen;

    tf::Matrix3x3 pitchRotation;

public:

    igor_states_no_sensor(ros::NodeHandle* nodehandle); // constructor
    ~igor_states_no_sensor(); // destructor


    float pitch_vel_y = 0;
    float yaw_vel_z = 0;
    geometry_msgs::Vector3 igor_angul_vel; // Vector3 type variable
    

    // Window size is 2*m+1
    const int m1 = 12;
    const int m2 = 5;
    const int m3 = 15;
    // Polynomial Order
    const int n1 = 0;
    const int n2 = 1;
    const int n3 = 3;
    // Initial Point Smoothing (ie evaluate polynomial at first point in the window)
    // Points are defined in range [-m;m]
    const int t1 = m1;
    const int t2 = m2;
    const int t3 = m3;
    // Derivate? 0: no derivation, 1: first derivative...
    const int d = 0;
    double result;
    gram_sg::SavitzkyGolayFilterConfig sg_conf1{m1,t1,n1,d,0.002}; // filter configuration
    gram_sg::SavitzkyGolayFilterConfig sg_conf2{m2,t2,n2,1,1}; // filter configuration
    gram_sg::SavitzkyGolayFilterConfig sg_conf3{m3,t3,n3,2,1}; // filter configuration
    
    gram_sg::SavitzkyGolayFilter f1{sg_conf1};
    gram_sg::SavitzkyGolayFilter f3{sg_conf3};
    gram_sg::SavitzkyGolayFilter f4{sg_conf3};
    gram_sg::SavitzkyGolayFilter f5{sg_conf3};
    gram_sg::SavitzkyGolayFilter pitch_vel_filt{sg_conf1};
    gram_sg::SavitzkyGolayFilter yaw_vel_filt{sg_conf1};
    gram_sg::SavitzkyGolayFilter L_wheel_pitch_vel_filt{sg_conf1};
    gram_sg::SavitzkyGolayFilter R_wheel_pitch_vel_filt{sg_conf1};
    //gram_sg::SavitzkyGolayFilter trq_r_filt{sg_conf1};
    //gram_sg::SavitzkyGolayFilter trq_l_filt{sg_conf1};
    
    boost::circular_buffer<double> rightTrqVector {boost::circular_buffer<double>((2*m1+1),0)}; // Initialize with 0
    boost::circular_buffer<double> leftTrqVector {boost::circular_buffer<double>((2*m1+1),0)}; // Initialize with 0
    boost::circular_buffer<double> pitchVelVector {boost::circular_buffer<double>((2*m1+1),0)};
    boost::circular_buffer<double> yawVelVector {boost::circular_buffer<double>((2*m1+1),0)};
    boost::circular_buffer<double> LWheelpitchVelVector {boost::circular_buffer<double>((2*m1+1),0)};
    boost::circular_buffer<double> RWheelpitchVelVector {boost::circular_buffer<double>((2*m1+1),0)};
    
    boost::circular_buffer<double> my_data1 {boost::circular_buffer<double>((2*m1+1),0)};
    boost::circular_buffer<double> my_data3 {boost::circular_buffer<double>((2*m3+1),-0.033)};
    boost::circular_buffer<double> my_data4 {boost::circular_buffer<double>((2*m3+1),-0.033)};
    boost::circular_buffer<double> my_data5 {boost::circular_buffer<double>((2*m3+1),-0.033)};

   

};