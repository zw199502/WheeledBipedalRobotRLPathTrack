import wandb
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Lambda, concatenate, Conv2D, MaxPool2D, Flatten, Reshape

import rospy
from velocity_publisher_navigation import VelocityPub
from local_navigation import IgorState
from std_srvs.srv import Empty

import argparse
import os
import time
import numpy as np

tf.keras.backend.set_floatx('float32')

wandb.init(name='PPO', project="deep-rl-tf2")

parser = argparse.ArgumentParser()
parser.add_argument('--gamma', type=float, default=0.99)
parser.add_argument('--update_interval', type=int, default=8)
parser.add_argument('--actor_lr', type=float, default=0.0005)
parser.add_argument('--critic_lr', type=float, default=0.001)
parser.add_argument('--clip_ratio', type=float, default=0.1)
parser.add_argument('--lmbda', type=float, default=0.95)
parser.add_argument('--epochs', type=int, default=4)
parser.add_argument('--max_linear_accel', type=float, default=0.5)
parser.add_argument('--max_angular_accel', type=float, default=1.0)

args = parser.parse_args()

##########  file log  ##################
ALG_NAME = 'PPO'
ENV_ID = 'igor_navigation'  # environment id

##########  GPU Config    ################
physical_devices = tf.config.experimental.list_physical_devices('GPU')
assert len(physical_devices) > 0, "Not enough GPU hardware devices available"
tf.config.experimental.set_visible_devices(physical_devices[0], 'GPU')
tf.config.experimental.set_memory_growth(physical_devices[0], True)


class Actor:
    def __init__(self, laser_dim, state_dim, action_dim, action_bound, std_bound):
        self.laser_dim = laser_dim
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.action_bound = action_bound
        self.std_bound = std_bound
        self.model = self.create_model()
        self.opt = tf.keras.optimizers.Adam(args.actor_lr)

    def get_action(self, inputs):
        inputs[0] = np.reshape(inputs[0], [1, self.laser_dim])
        inputs[1] = np.reshape(inputs[1], [1, self.state_dim])
        mu, std = self.model.predict(inputs)
        # print(std[0])
        # print(mu[0])
        action = np.random.normal(mu[0], std[0], size=self.action_dim)
        # print(action)
        action = np.clip(action, -self.action_bound, self.action_bound)
        # print(action)
        action = np.float32(action)
        log_policy = self.log_pdf(mu, std, action)

        return log_policy, action

    def log_pdf(self, mu, std, action):
        std = tf.clip_by_value(std, self.std_bound[0], self.std_bound[1])
        var = std ** 2
        log_policy_pdf = -0.5 * (action - mu) ** 2 / \
            var - 0.5 * tf.math.log(var * 2 * np.pi)
        return tf.reduce_sum(log_policy_pdf, 1, keepdims=True)

    def create_model(self):
        _input_shape = (self.laser_dim,)
        laser_input = Input(_input_shape, name='policy_laser_input')
        laser_input_matrix = Reshape((4, int(self.laser_dim/4), 1), input_shape=_input_shape, 
                                      name='policy_reshape')(laser_input)
        conv1 = Conv2D(
           16,             # number of kernel
           kernel_size=[2, 2], 
           activation='relu',
           name='policy_c1'   
        )(laser_input_matrix)
        pool1 = MaxPool2D(pool_size=[1, 2], name='policy_p1')(conv1)
        conv2 = Conv2D(
            16,
            kernel_size=[2, 2],
            activation='relu',
            name='policy_c2' 
        )(pool1)
        pool2 = MaxPool2D(pool_size=[1, 2], name='policy_p2')(conv2)
        flatten1 = Flatten(name='policy_flatten')(pool2)
        dense1 = Dense(128, activation='relu', name='policy_dense1')(flatten1)
        dense2 = Dense(32,  activation='relu', name='policy_dense2')(dense1)

        state_input = Input((self.state_dim,), name='policy_state_input')

        connect1 = concatenate([dense2, state_input], axis=-1)
        linear1 = Dense(128, activation='relu', name='policy1')(connect1)
        linear2 = Dense(64,  activation='relu', name='policy2')(linear1)
        linear3 = Dense(32,  activation='relu', name='policy3')(linear2)

        out_mu = Dense(self.action_dim, activation='tanh')(linear3)
        mu_output = Lambda(lambda x: x * self.action_bound)(out_mu)
        std_output = Dense(self.action_dim, activation='softplus')(linear3)

        return Model([laser_input, state_input], [mu_output, std_output])

    def compute_loss(self, log_old_policy, log_new_policy, gaes):
        ratio = tf.exp(log_new_policy - tf.stop_gradient(log_old_policy))
        gaes = tf.stop_gradient(gaes)
        clipped_ratio = tf.clip_by_value(
            ratio, 1.0-args.clip_ratio, 1.0+args.clip_ratio)
        clipped_ratio = tf.cast(clipped_ratio, tf.float32)
        ratio = tf.cast(ratio, tf.float32)
        gaes = tf.cast(gaes, tf.float32)
        surrogate = -tf.minimum(ratio * gaes, clipped_ratio * gaes)
        return tf.reduce_mean(surrogate)

    def train(self, log_old_policy, inputs, actions, gaes):
        with tf.GradientTape() as tape:
            mu, std = self.model(inputs, training=True)
            log_new_policy = self.log_pdf(mu, std, actions)
            loss = self.compute_loss(
                log_old_policy, log_new_policy, gaes)
        grads = tape.gradient(loss, self.model.trainable_variables)
        self.opt.apply_gradients(zip(grads, self.model.trainable_variables))
        return loss


class Critic:
    def __init__(self, laser_dim, state_dim):
        self.laser_dim = laser_dim
        self.state_dim = state_dim
        self.model = self.create_model()
        self.opt = tf.keras.optimizers.Adam(args.critic_lr)

    def create_model(self):
        _input_shape = (self.laser_dim,)
        laser_input = Input(_input_shape, name='v_laser_input')
        laser_input_matrix = Reshape((4, int(self.laser_dim/4), 1), input_shape=_input_shape, 
                                      name='v_reshape')(laser_input)
        conv1 = Conv2D(
           16,             # number of kernel
           kernel_size=[2, 2], 
           activation='relu',
           name='v_c1'   
        )(laser_input_matrix)
        pool1 = MaxPool2D(pool_size=[1, 2], name='v_p1')(conv1)
        conv2 = Conv2D(
            16,
            kernel_size=[2, 2],
            activation='relu',
            name='v_c2' 
        )(pool1)
        pool2 = MaxPool2D(pool_size=[1, 2], name='v_p2')(conv2)

        flatten1 = Flatten(name='v_flatten')(pool2)
        dense1 = Dense(128, activation='relu', name='v_dense1')(flatten1)
        dense2 = Dense(32,  activation='relu', name='v_dense2')(dense1)

        state_input = Input((self.state_dim,), name='v_state_input')

        connect1 = concatenate([dense2, state_input], axis=-1)
        linear1 = Dense(128, activation='relu',   name='v1')(connect1)
        linear2 = Dense(64,  activation='relu',   name='v2')(linear1)
        v_out = Dense(1,   activation='linear', name='v3')(linear2)
        return Model([laser_input, state_input], v_out)

    def compute_loss(self, v_pred, td_targets):
        mse = tf.keras.losses.MeanSquaredError()
        return mse(td_targets, v_pred)

    def train(self, inputs, td_targets):
        with tf.GradientTape() as tape:
            v_pred = self.model(inputs, training=True)
            assert v_pred.shape == td_targets.shape
            loss = self.compute_loss(v_pred, tf.stop_gradient(td_targets))
        grads = tape.gradient(loss, self.model.trainable_variables)
        self.opt.apply_gradients(zip(grads, self.model.trainable_variables))
        return loss


class Agent:
    def __init__(self):
        self.laser_dim = 736
        self.state_dim = 4
        self.action_dim = 2
        
        self.action_bound = 1.0

        self.std_bound = [1e-2, 1.0]

        self.actor_opt = tf.keras.optimizers.Adam(args.actor_lr)
        self.critic_opt = tf.keras.optimizers.Adam(args.critic_lr)
        self.actor = Actor(self.laser_dim, self.state_dim, self.action_dim,
                           self.action_bound, self.std_bound)
        self.critic = Critic(self.laser_dim, self.state_dim)

    def gae_target(self, rewards, v_values, next_v_value, done):
        n_step_targets = np.zeros_like(rewards)
        gae = np.zeros_like(rewards)
        gae_cumulative = 0
        forward_val = 0

        if not done:
            forward_val = next_v_value

        for k in reversed(range(0, len(rewards))):
            delta = rewards[k] + args.gamma * forward_val - v_values[k]
            gae_cumulative = args.gamma * args.lmbda * gae_cumulative + delta
            gae[k] = gae_cumulative
            forward_val = v_values[k]
            n_step_targets[k] = gae[k] + v_values[k]
        return gae, n_step_targets

    def list_to_batch(self, _list):
        batch = _list[0]
        for elem in _list[1:]:
            batch = np.append(batch, elem, axis=0)
        return batch

    def save(self):  # save trained weights
        path = os.path.join('model', '_'.join([ALG_NAME, ENV_ID]))
        if not os.path.exists(path):
            os.makedirs(path)
        extend_path = lambda s: os.path.join(path, s)
        self.actor.model.save_weights(extend_path('actor.h5'))
        self.critic.model.save_weights(extend_path('critic.h5'))

    def load_weights(self):  # load trained weights
        path = os.path.join('model', '_'.join([ALG_NAME, ENV_ID]))
        extend_path = lambda s: os.path.join(path, s)
        self.actor.model.load_weights(extend_path('actor.h5'))
        self.critic.model.load_weights(extend_path('critic.h5'))

    def train(self, max_episodes=1000):
        unpause = rospy.ServiceProxy('/gazebo/unpause_physics', Empty)
        pause = rospy.ServiceProxy('/gazebo/pause_physics', Empty)
        last_action = np.zeros((self.action_dim,))

        running_step = 0.1 # control frequency: 10Hz
        igor_state_object = IgorState()
        igor_velocity_pubisher_object = VelocityPub()
        for ep in range(max_episodes):
            laser_state_batch = []
            state_batch = []
            action_batch = []
            reward_batch = []
            old_policy_batch = []

            episode_reward, done = 0, False
            episode_reward_save = np.zeros(max_episodes)

            # print("set_init_robot_state...")
            igor_state_object.set_initial_robot_state()
            # print("set_init_command_velocity...")
            igor_velocity_pubisher_object.set_init_velocity_state()
            rospy.sleep(3.0)
            laser_state, state = igor_state_object.get_observations()

            while not done:
                # self.env.render()
                # time_1 = time.time()
                log_old_policy, action = self.actor.get_action([laser_state, state])
                # time_2 = time.time()
                # print(time_2 - time_1) # 0.0032 ~ 0.0078

                # linear velocity range [0, 0.2]
                action[0] = (action[0] + 1.0) * 0.1
                # angular velocity range [-0.6, 0.6]
                action[1] = action[1] * 0.6
                # default maximum linear acceleration 0.5
                # default maximum angular acceleration 1.0
                # if ((action[0] - last_action[0]) > (running_step * args.max_linear_accel)):
                #     action[0] = last_action[0] + running_step * args.max_linear_accel
                # if ((action[0] - last_action[0]) < (-running_step * args.max_linear_accel)):
                #     action[0] = last_action[0] - running_step * args.max_linear_accel
                # if ((action[1] - last_action[1]) > (running_step * args.max_angular_accel)):
                #     action[1] = last_action[1] + running_step * args.max_angular_accel
                # if ((action[1] - last_action[1]) < (-running_step * args.max_angular_accel)):
                #     action[1] = last_action[1] - running_step * args.max_angular_accel
                print(action)
                igor_velocity_pubisher_object.pub_vel(action)
                rospy.sleep(running_step - 0.005)
                last_action = action
                # print(rospy.get_time())

                # We now process the latest data saved in the class state to calculate
                # the state and the rewards. This way we guarantee that they work
                # with the same exact data.
                # Generate State based on observations
                next_laser_state, next_state = igor_state_object.get_observations()
                # finally we get an evaluation based on what happened in the sim
                reward, done, info = igor_state_object.process_data()
                # Pause simulation
                
                laser_state = np.reshape(laser_state, [1, self.laser_dim]) 
                state = np.reshape(state, [1, self.state_dim])
                action = np.reshape(action, [1, self.action_dim])
                next_laser_state = np.reshape(next_laser_state, [1, self.laser_dim])
                next_state = np.reshape(next_state, [1, self.state_dim])
                reward = np.reshape(reward, [1, 1])
                log_old_policy = np.reshape(log_old_policy, [1, 1])

                laser_state_batch.append(laser_state)
                state_batch.append(state)
                action_batch.append(action)
                reward_batch.append((reward+8)/8)
                old_policy_batch.append(log_old_policy)

                if len(state_batch) >= args.update_interval or done:
                    rospy.wait_for_service('/gazebo/pause_physics')
                    try:
                        pause()
                    except (rospy.ServiceException, e):
                        print ("/gazebo/pause_physics service call failed")
                    # time_3 = time.time()
                    laser_state = self.list_to_batch(laser_state_batch)
                    states = self.list_to_batch(state_batch)
                    actions = self.list_to_batch(action_batch)
                    rewards = self.list_to_batch(reward_batch)
                    old_policys = self.list_to_batch(old_policy_batch)

                    v_values = self.critic.model.predict([laser_state, states])
                    next_v_value = self.critic.model.predict([next_laser_state, next_state])

                    gaes, td_targets = self.gae_target(
                        rewards, v_values, next_v_value, done)

                    for epoch in range(args.epochs):
                        inputs = [laser_state, states]
                        actor_loss = self.actor.train(
                            old_policys, inputs, actions, gaes)
                        critic_loss = self.critic.train(inputs, td_targets)
                    # time_4 = time.time()
                    # print(time_4-time_3) # 0.1766 ~ 0.2016
                    laser_state_batch = []
                    state_batch = []
                    action_batch = []
                    reward_batch = []
                    old_policy_batch = []

                    # unpause simulation
                    rospy.wait_for_service('/gazebo/unpause_physics')
                    try:
                        unpause()
                    except (rospy.ServiceException, e):
                        print ("/gazebo/unpause_physics service call failed")
                    

                episode_reward += reward[0][0]
                laser_state = next_laser_state[0]
                state = next_state[0]
            episode_reward_save[ep] = episode_reward
            print('EP{} EpisodeReward={}'.format(ep, episode_reward))
            wandb.log({'Reward': episode_reward})
        if ((ep > 0) and (ep % 100 == 0)):
            np.savetxt('episode_reward.txt', episode_reward_save)
            self.save()  # save net weights


def main():
    rospy.init_node('igor_main', anonymous=True, log_level=rospy.INFO)
    agent = Agent()
    agent.train()


if __name__ == "__main__":
    main()
