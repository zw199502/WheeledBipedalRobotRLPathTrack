import numpy as np
import matplotlib.pyplot as plt

from matplotlib import animation

########################
# ten simulation tests
########################
d1 = np.loadtxt('test_d.txt')
d2 = np.loadtxt('test_d2.txt')
theta1 = np.loadtxt('test_theta.txt')
theta2 = np.loadtxt('test_theta2.txt')
_t1 = np.loadtxt('test_time.txt')
t1 = np.zeros((10,1000))
_t2 = np.loadtxt('test_time2.txt')
t2 = np.zeros((10,1000))

t1_adjust = np.zeros(10)
t2_adjust = np.zeros(10)

d1_adjust = np.zeros(10)
d2_adjust = np.zeros(10)

theta1_adjust = np.zeros(10)
theta2_adjust = np.zeros(10)

d1_ini = np.zeros(10)
d2_ini = np.zeros(10)

theta1_ini = np.zeros(10)
theta2_ini = np.zeros(10)

for i in range(10):
    for j in range(999):
        t1[i, j+1] = _t1[i, j+1] - _t1[i, 0]
        t2[i, j+1] = _t2[i, j+1] - _t2[i, 0]
for i in range(10):
    t1[i, 0] = 0
    t2[i, 0] = 0

for p in range(10):
    d1_ini[p] = d1[p,0]
    theta1_ini[p] = theta1[p,0]
    for k in range(900):
        for m in range(100):
            if (np.abs(d1[p,k+m]) >= 0.05) or np.abs(theta1[p,k+m] >= 0.087):
                break
        if m == 99:
            t1_adjust[p] = t1[p, k]
            d1_adjust[p] = d1[p, k]
            theta1_adjust[p] = theta1[p, k]
            break


for p in range(10):
    d2_ini[p] = d2[p,0]
    theta2_ini[p] = theta2[p,0]
    for k in range(900):
        for m in range(100):
            if (np.abs(d2[p,k+m]) >= 0.05) or np.abs(theta2[p,k+m] >= 0.087):
                break
        if m == 99:
            t2_adjust[p] = t2[p, k]
            d2_adjust[p] = d2[p, k]
            theta2_adjust[p] = theta2[p, k]
            break

d_ini = (d1_ini + d2_ini) / 2.0
theta_ini = (theta1_ini + theta2_ini) / 2.0
print("%.3f" % theta_ini[0], '&', "%.3f" % theta_ini[1], '&', 
"%.3f" % theta_ini[2], '&', "%.3f" % theta_ini[3], '&', 
"%.3f" % theta_ini[4], '&', "%.3f" % theta_ini[5], '&', 
"%.3f" % theta_ini[6], '&', "%.3f" % theta_ini[7], '&', 
"%.3f" % theta_ini[8], '&', "%.3f" % theta_ini[9])
print("%.3f" % d_ini[0], '&', "%.3f" % d_ini[1], '&', 
"%.3f" % d_ini[2], '&', "%.3f" % d_ini[3], '&', 
"%.3f" % d_ini[4], '&', "%.3f" % d_ini[5], '&', 
"%.3f" % d_ini[6], '&', "%.3f" % d_ini[7], '&', 
"%.3f" % d_ini[8], '&', "%.3f" % d_ini[9])

print("%.3f" % t1_adjust[0], '&', "%.3f" % t1_adjust[1], '&', 
"%.3f" % t1_adjust[2], '&', "%.3f" % t1_adjust[3], '&', 
"%.3f" % t1_adjust[4], '&', "%.3f" % t1_adjust[5], '&', 
"%.3f" % t1_adjust[6], '&', "%.3f" % t1_adjust[7], '&', 
"%.3f" % t1_adjust[8], '&', "%.3f" % t1_adjust[9])
print("%.3f" % t2_adjust[0], '&', "%.3f" % t2_adjust[1], '&', 
"%.3f" % t2_adjust[2], '&', "%.3f" % t2_adjust[3], '&', 
"%.3f" % t2_adjust[4], '&', "%.3f" % t2_adjust[5], '&', 
"%.3f" % t2_adjust[6], '&', "%.3f" % t2_adjust[7], '&', 
"%.3f" % t2_adjust[8], '&', "%.3f" % t2_adjust[9])
print("%.3f" % theta1_adjust[0], '&', "%.3f" % theta1_adjust[1], '&', 
"%.3f" % theta1_adjust[2], '&', "%.3f" % theta1_adjust[3], '&', 
"%.3f" % theta1_adjust[4], '&', "%.3f" % theta1_adjust[5], '&', 
"%.3f" % theta1_adjust[6], '&', "%.3f" % theta1_adjust[7], '&', 
"%.3f" % theta1_adjust[8], '&', "%.3f" % theta1_adjust[9])
print("%.3f" % theta2_adjust[0], '&', "%.3f" % theta2_adjust[1], '&', 
"%.3f" % theta2_adjust[2], '&', "%.3f" % theta2_adjust[3], '&', 
"%.3f" % theta2_adjust[4], '&', "%.3f" % theta2_adjust[5], '&', 
"%.3f" % theta2_adjust[6], '&', "%.3f" % theta2_adjust[7], '&', 
"%.3f" % theta2_adjust[8], '&', "%.3f" % theta2_adjust[9])
print("%.3f" % d1_adjust[0], '&', "%.3f" % d1_adjust[1], '&', 
"%.3f" % d1_adjust[2], '&', "%.3f" % d1_adjust[3], '&', 
"%.3f" % d1_adjust[4], '&', "%.3f" % d1_adjust[5], '&', 
"%.3f" % d1_adjust[6], '&', "%.3f" % d1_adjust[7], '&', 
"%.3f" % d1_adjust[8], '&', "%.3f" % d1_adjust[9])
print("%.3f" % d2_adjust[0], '&', "%.3f" % d2_adjust[1], '&', 
"%.3f" % d2_adjust[2], '&', "%.3f" % d2_adjust[3], '&', 
"%.3f" % d2_adjust[4], '&', "%.3f" % d2_adjust[5], '&', 
"%.3f" % d2_adjust[6], '&', "%.3f" % d2_adjust[7], '&', 
"%.3f" % d2_adjust[8], '&', "%.3f" % d2_adjust[9])


ave1 = np.sum(np.abs(t1_adjust)) / 10
ave2 = np.sum(np.abs(t2_adjust)) / 10
ave3 = np.sum(np.abs(theta1_adjust)) / 10
ave4 = np.sum(np.abs(theta2_adjust)) / 10
ave5 = np.sum(np.abs(d1_adjust)) / 10
ave6 = np.sum(np.abs(d2_adjust)) / 10
std1 = (np.abs(t1_adjust)).std()
std2 = (np.abs(t2_adjust)).std()
std3 = (np.abs(theta1_adjust)).std()
std4 = (np.abs(theta2_adjust)).std()
std5 = (np.abs(d1_adjust)).std()
std6 = (np.abs(d2_adjust)).std()
print(ave1, ave2, ave3, ave4, ave5, ave6)
print(std1, std2, std3, std4, std5, std6)


#######################
# one simulation test
#######################
# plt.figure(12)
# plt.subplot(221)
# # plt.xlabel("time/s")
# plt.ylabel("orientation error/rad")
# plt.plot(t1[0,:], theta1[0,:], label='proposed')
# plt.plot(t2[0,:], theta2[0,:], label='comparison', linestyle='--')
# plt.legend()
# plt.subplot(222)
# # plt.xlabel("time/s")
# # plt.ylabel("orientation error/rad")
# plt.plot(t1[1,:], theta1[1,:])
# plt.plot(t2[1,:], theta2[1,:],linestyle='--')
# plt.subplot(223)
# plt.xlabel("time/s")
# plt.ylabel("distance error/m")
# plt.plot(t1[0,:], d1[0,:])
# plt.plot(t2[0,:], d2[0,:],linestyle='--')
# plt.subplot(224)
# plt.xlabel("time/s")
# # plt.ylabel("orientation error/rad")
# plt.plot(t1[1,:], d1[1,:])
# plt.plot(t2[1,:], d2[1,:],linestyle='--')

# plt.show()


#####################################
# animate figure
#####################################
# First set up the figure, the axis, and the plot element we want to animate
# fig = plt.figure()
# # ax = plt.axes(xlim=(-2, 52), ylim=(-0.82, 0.02))
# ax = plt.axes(xlim=(-2, 52), ylim=(-0.05, 1.23))
# plt.xlabel("time/s")
# # plt.ylabel("distance error/m")
# plt.ylabel("orientation error/rad")
# # ax = plt.axes(xlim=(0, 2), ylim=(-2, 2))
# line, = ax.plot([], [], lw=2)
# # initialization function: plot the background of each frame
# def init():
#     line.set_data([], [])
#     return line,

# # animation function.  This is called sequentially
# def animate(i):
#     # x = np.linspace(0, 2, 1000)
#     # y = np.sin(2 * np.pi * (x - 0.01 * i))
#     x = t2[0,0:i]
#     y = theta2[0,0:i]
#     # y = theta1[0,0:i]
#     line.set_data(x, y)
#     return line,

# # call the animator.  blit=True means only re-draw the parts that have changed.
# anim = animation.FuncAnimation(fig, animate, init_func=init,
#                                frames=1000, interval=20, blit=True)

# # save the animation as an mp4.  This requires ffmpeg or mencoder to be
# # installed.  The extra_args ensure that the x264 codec is used, so that
# # the video can be embedded in html5.  You may need to adjust this for
# # your system: for more information, see
# # http://matplotlib.sourceforge.net/api/animation_api.html
# anim.save('basic_animation.mp4', fps=19, extra_args=['-vcodec', 'libx264'])

# plt.show()


##################################
# episode reward
##################################
reward1 = np.loadtxt('reward.txt')
reward2 = np.loadtxt('reward2.txt')

plt.figure(12)
plt.subplot(211)
plt.ylabel("average_reward ")
plt.plot(reward1/100.0, label='proposed')
plt.legend()

plt.subplot(212)
plt.ylabel("average_reward ")
plt.xlabel("episode")
plt.plot(reward2/1000.0,label='comparison')
plt.legend()
plt.show()
