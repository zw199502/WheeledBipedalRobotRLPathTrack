#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist


class VelocityPub():
    def __init__(self):
        self.cmd_vel = rospy.Publisher('/igor/commands/velocity', Twist, queue_size=1)
        self.init_vel_state = [0.0, 0.0]

    def set_init_velocity_state(self):
        self.pub_vel(self.init_vel_state)

    def pub_vel(self, vel_state_array):
        move_cmd = Twist()
        move_cmd.linear.x = vel_state_array[0]
        move_cmd.angular.z = vel_state_array[1]
        self.cmd_vel.publish(move_cmd)
       