#!/usr/bin/env python
'''
    By Miguel Angel Rodriguez <duckfrost@theconstructsim.com>
    Visit our website at www.theconstructsim.com
'''

import rospy
import numpy as np
import time
import math

from geometry_msgs.msg import Pose
from gazebo_connection import GazeboConnection
from velocity_publisher import VelocityPub
from straight_line_following import IgorState


class IgorEnv():

    def __init__(self):
        self.desired_linear_velocity = 0.0
        self.desired_angular_velocity = 0.0
        self.running_step = 0.05 # control frequency: 20Hz
        self.igor_state_object = IgorState()        
        self.igor_velocity_pubisher_object = VelocityPub()


    # Resets the state of the environment and returns an initial observation.
    def reset(self):
        # print("set_init_robot_state...")
        self.igor_state_object.set_initial_robot_state()
        # print("set_init_command_velocity...")
        self.igor_velocity_pubisher_object.set_init_velocity_state()
        rospy.sleep(3.0)
        state_after_reset = self.igor_state_object.get_observations()

        return state_after_reset

    def step(self, action):

        # Given the action selected by the learning algorithm,
        # we perform the corresponding movement of the robot

        # We move it to that action
        # self.gazebo.unpauseSim()
        # period of changing control gain: self.running_step mulitply ten
        
        for i in range(10):
            state_after_action = self.igor_state_object.get_observations()
            e_theta = state_after_action[0]
            e_d = state_after_action[1]
            a = -action[0] * e_d * math.sin(e_theta) / e_theta - action[1] * e_theta
            if a > 0.6:
                a = 0.6
            if a < -0.6:
                a = -0.6
            self.igor_velocity_pubisher_object.pub_vel(np.array([a,]))
            # Then we send the command to the robot and let it go
            # for running_step seconds
            rospy.sleep(self.running_step)
        # print(rospy.get_time())
        # self.gazebo.pauseSim()

        # We now process the latest data saved in the class state to calculate
        # the state and the rewards. This way we guarantee that they work
        # with the same exact data.
        # Generate State based on observations
        state_after_action = self.igor_state_object.get_observations()

        # finally we get an evaluation based on what happened in the sim
        reward, done, info = self.igor_state_object.process_data()

        return state_after_action, reward, done, info