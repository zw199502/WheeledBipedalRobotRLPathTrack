#!/usr/bin/env python

import rospy
import copy
from std_srvs.srv import Empty
from std_msgs.msg import Float32MultiArray
from gazebo_msgs.srv import SetModelState, SetModelStateRequest, GetModelState, GetModelStateRequest, SetModelConfiguration, SetModelConfigurationRequest
from gazebo_msgs.msg import ContactsState
from gazebo_msgs.msg import ModelState
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, Vector3
import numpy
import math

import message_filters
from sensor_msgs.msg import Imu

class IgorState(object):

    def __init__(self):
        rospy.logdebug("Starting igorState Class object...")
        
        self.pose_state_dim = 3
        self.velocity_state_dim = 2

        # init_target_pose: world frame
        self.init_target_pose = numpy.array([0.5, 0.5, 0.0])
        # print('init_target_pose', self.init_target_pose)
        # robot_pose: world frame
        self.robot_pose = numpy.zeros(self.pose_state_dim)
       
        # current_target_pose: robot frame
        self.current_target_pose = numpy.zeros(self.pose_state_dim)
        # last_target_pose: robot frame
        self.last_target_pose = numpy.zeros(self.pose_state_dim)

        self.current_time_velocity = numpy.zeros(self.velocity_state_dim)
        self.last_time_velocity = numpy.zeros(self.velocity_state_dim)

        self.current_step = 0
        self.episode_steps = 600

        self.d_theta = 0.0
        self.d_c = 0.0
        self.d_l = 0.0
        self._lean_angle = 0.0
        self._lean_velocity = 0.0
        self._lean_state = numpy.array([0.0, 0.0])

        self._arrive_reward = 100
        self._lean_failure_reward = -500
        self.r_orientation = 1.0
        self.r_distance = 1.0
        self.r_lean_angle = 10.0
        self.r_lean_velocity = 5.0

        self.get_state_service = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
        self.model = GetModelStateRequest()
        self.model.model_name = 'igor'
        self.base_orientation = Quaternion()
        
        self.model_state_proxy = rospy.ServiceProxy('/gazebo/set_model_state',SetModelState)
        self.model_state_req = SetModelStateRequest()
        self.model_state_req.model_state = ModelState()
        self.model_state_req.model_state.model_name = 'igor'
        self.model_state_req.model_state.pose.position.x = 0.0
        self.model_state_req.model_state.pose.position.y = 0.0
        self.model_state_req.model_state.pose.position.z = 0.861
        self.model_state_req.model_state.pose.orientation.x = 0.0
        self.model_state_req.model_state.pose.orientation.y = 0.0
        self.model_state_req.model_state.pose.orientation.z = 0.0
        self.model_state_req.model_state.pose.orientation.w = 1.0   # 0.0
        self.model_state_req.model_state.twist.linear.x = 0.0
        self.model_state_req.model_state.twist.linear.y = 0.0
        self.model_state_req.model_state.twist.linear.z = 0.0
        self.model_state_req.model_state.twist.angular.x = 0.0
        self.model_state_req.model_state.twist.angular.y = 0.0
        self.model_state_req.model_state.twist.angular.z = 0.0
        self.model_state_req.model_state.reference_frame = 'world'  

        self.joint_name_lst = ['L_hfe_joint', 'L_kfe_joint', 'L_wheel_joint', 'R_hfe_joint', 'R_kfe_joint', 'R_wheel_joint']
        self.starting_pos = numpy.array([0.329, -0.65, 0.0, 0.329, -0.65, 0.0])
        self.model_config_proxy = rospy.ServiceProxy('/gazebo/set_model_configuration',SetModelConfiguration)
        self.model_config_req = SetModelConfigurationRequest()
        self.model_config_req.model_name = 'igor'
        self.model_config_req.urdf_param_name = 'robot_description'
        self.model_config_req.joint_names = self.joint_name_lst
        self.model_config_req.joint_positions = self.starting_pos

        self.pause_proxy = rospy.ServiceProxy('/gazebo/pause_physics',Empty)
        self.unpause_proxy = rospy.ServiceProxy('/gazebo/unpause_physics',Empty)

        # body_imu_sub = message_filters.Subscriber('/igor/body_imu/data', Imu)
        # Lwheel_imu_sub = message_filters.Subscriber('/igor/L_wheel_imu/data', Imu)
        # Rwheel_imu_sub = message_filters.Subscriber('/igor/R_wheel_imu/data', Imu)
        # ts = message_filters.TimeSynchronizer([body_imu_sub, Lwheel_imu_sub, Rwheel_imu_sub], 10)
        # ts.registerCallback(self.SynCallback)
        # self.current_time = 0.0
        # self.last_time = 0.0
        # self.r_wheel = 0.1016

        rospy.Subscriber('/igor/igor_state', Float32MultiArray, self.StateCallback, queue_size=5)
       
    def StateCallback(self, msg):
        self.robot_pose[0] = msg.data[0]
        self.robot_pose[1] = msg.data[1]
        self.robot_pose[2] = msg.data[2]
        self.current_time_velocity[0] = msg.data[3]
        self.current_time_velocity[1] = msg.data[4]
        self._lean_angle = msg.data[5]
        self._lean_velocity = msg.data[6]
        self._lean_state[0] = self._lean_angle
        self._lean_state[1] = self._lean_velocity

    def set_initial_robot_state(self):
        self.current_step = 0
        rospy.wait_for_service('/gazebo/pause_physics')
        try:
            self.pause_proxy()
        except rospy.ServiceException:
            print('/gazebo/pause_physics service call failed')

        #set models pos from world
        rospy.wait_for_service('/gazebo/set_model_state')
        try:
            self.model_state_proxy(self.model_state_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_state call failed')

        #set model's joint config
        rospy.wait_for_service('/gazebo/set_model_configuration')
        try:
            self.model_config_proxy(self.model_config_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_configuration call failed')
     
        #unpause physics
        rospy.wait_for_service('/gazebo/unpause_physics')
        try:
            self.unpause_proxy()
        except rospy.ServiceException:
            print('/gazebo/unpause_physics service call failed')
        
        self.init_target_pose = numpy.random.random(3) * 2.0 - 1.0
        self.init_target_pose[2] = self.init_target_pose[2] * numpy.pi
        print('init_target_pose', self.init_target_pose)
    
    def igor_lean_ok(self):
        lean_ok = True
        if numpy.abs(self._lean_angle) > numpy.pi / 10:
            lean_ok = False
        return lean_ok

    def target_arrival_ok(self):
        arrival_ok = True
        if self.d_c >= 0.05 or self.d_theta >= 0.1:
            arrival_ok = False
        return arrival_ok

    def calculate_reward_distance_orientation(self):
        # reward = -self.r_distance * (self.d_c - self.d_l)     
        reward = -(self.r_distance * self.d_c + self.r_orientation * self.d_theta)
        rospy.logdebug("calculate_reward_distance_orientation>>reward=" + str(reward))
        return reward        

    def calculate_reward_lean_angle(self):
        reward = -self.r_lean_angle * numpy.abs(self._lean_angle)
        rospy.logdebug("calculate_reward_lean_angle>>reward=" + str(reward))
        return reward

    def calculate_reward_lean_velocity(self):
        reward = -self.r_lean_velocity * numpy.abs(self._lean_velocity)
        rospy.logdebug("calculate_reward_lean_velocity>>reward=" + str(reward))
        return reward


    def calculate_total_reward(self):
        r1 = self.calculate_reward_distance_orientation()
        # r2 = self.calculate_reward_lean_angle()
        # r3 = self.calculate_reward_lean_velocity()
        
        # The sign depend on its function.
        # total_reward = r1 + r2 + r3
        total_reward = r1
        rospy.logdebug("total_reward=" + str(total_reward))
        return total_reward

    def get_base_rpy(self):
        w = self.base_orientation.w
        x = self.base_orientation.x
        y = self.base_orientation.y
        z = self.base_orientation.z
        r = math.atan2(2*(w*x+y*z),1-2*(x*x+y*y))
        p = math.asin(2*(w*y-z*x))
        y = math.atan2(2*(w*z+x*y),1-2*(z*z+y*y))       
        euler_rpy = Vector3()
        euler_rpy.x = r
        euler_rpy.y = p
        euler_rpy.z = y
        return euler_rpy

    def get_observations(self):
        # objstate = self.get_state_service(self.model)
        # self.robot_pose[0] = objstate.pose.position.x  # x
        # self.robot_pose[1] = objstate.pose.position.y  # y
        # self.base_orientation = objstate.pose.orientation
        # rpy = self.get_base_rpy()
        # self.robot_orientation = rpy.z  # yaw
        # linear_x = objstate.twist.linear.x
        # linear_y = objstate.twist.linear.y
        # linear = linear_x * math.cos(rpy.z) + linear_y * math.sin(rpy.z)
        # self.current_time_velocity[0] = linear # linear velocity
        # self.current_time_velocity[1] = objstate.twist.angular.z # angular velocity

        # self._lean_angle = rpy.y
        # self._lean_velocity = objstate.twist.angular.y

        dx = self.init_target_pose[0] - self.robot_pose[0]
        dy = self.init_target_pose[1] - self.robot_pose[1]
        s_theta = math.sin(self.robot_pose[2])
        c_theta = math.cos(self.robot_pose[2])
        self.current_target_pose[0] = dx * c_theta + dy * s_theta
        self.current_target_pose[1] = -dx * s_theta + dy * c_theta
        self.current_target_pose[2] = self.init_target_pose[2] - self.robot_pose[2] 

        # print('robot_pose: ', self.robot_pose)
        # print('robot_orientation: ', self.robot_orientation)
        # print('init_target_pose: ', self.init_target_pose)
        # print('current_target_pose: ', self.current_target_pose)


        if (self.current_step == 0):
            self.last_target_pose = self.current_target_pose
            self.last_time_velocity = self.current_time_velocity
        self.d_c = numpy.sqrt(numpy.power(self.current_target_pose[0,], 2) + \
                        numpy.power(self.current_target_pose[1,], 2))
        self.d_l = numpy.sqrt(numpy.power(self.last_target_pose[0,], 2) + \
                        numpy.power(self.last_target_pose[1,], 2))
        self.d_theta = numpy.abs(self.current_target_pose[2])
        observation_1 = numpy.append(self.current_target_pose, self.last_time_velocity)
        observation_return = numpy.append(observation_1, self._lean_state)
        self.last_target_pose = self.current_target_pose
        self.last_time_velocity = self.current_time_velocity
        return observation_return


    def process_data(self):
        done = False
        info = ""

        lean_ok = self.igor_lean_ok()
        rospy.logdebug("igor_lean_ok=" + str(lean_ok))
        if (lean_ok == False):
            done = True
            info ="lean_failure"
            print(info + ' at step: ' + str(self.current_step))
            return self._lean_failure_reward, done, info

        arrival_ok = self.target_arrival_ok()
        rospy.logdebug("target_arrival_ok=" + str(arrival_ok))
        if (arrival_ok == True):
            done = True
            info ="target_arrival_ok"
            print(info + ' at step: ' + str(self.current_step))
            
            return self._arrive_reward, done, info

        
        if (self.current_step >= self.episode_steps):
            done = True
            info = "max_step"
            print(info + ' arrived')
        total_reward = self.calculate_total_reward()
        # print(self.d_c)
        self.current_step = self.current_step + 1
        # print(self.current_step)

        return total_reward, done, info
