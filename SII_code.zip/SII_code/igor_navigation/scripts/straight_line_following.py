#!/usr/bin/env python

import rospy
import copy
from std_srvs.srv import Empty
from std_msgs.msg import Float32MultiArray
from gazebo_msgs.srv import SetModelState, SetModelStateRequest, GetModelState, GetModelStateRequest, SetModelConfiguration, SetModelConfigurationRequest
from gazebo_msgs.msg import ContactsState
from gazebo_msgs.msg import ModelState
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, Vector3
import numpy as np
import math

import message_filters
from sensor_msgs.msg import Imu

class IgorState(object):

    def __init__(self):
        # target straight line in world frame
        self.k_line = 0.0
        self.b_line = 0.0
        self.line_angle = math.atan2(self.k_line, 1)
        # errors
        self.e_d = 0.0 # distance error
        self.e_theta = 0.0 # orientation error 
        # reward weight
        self.weight_d = 8.0
        self.weight_theta = 0.5

        # robot_position: world frame
        self.robot_position = np.zeros(2)
        # robot_orientation: world frame
        self.robot_orientation = 0.0

        self.current_time_velocity = np.zeros(2)
        self.last_time_velocity = np.zeros(2)

        self.target_linear_velocity = 0.1
        self.e_linear_velocity = 0.0
        self.weight_linear_velocity = 1.0

        self._lean_angle = 0.0
        self.weight_lean_angle_reward = 10.0

        self._lean_failure_reward = -500
        
        self.current_step = 0

        self.get_state_service = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
        self.model = GetModelStateRequest()
        self.model.model_name = 'igor'
        self.base_orientation = Quaternion()
        
        self.model_state_proxy = rospy.ServiceProxy('/gazebo/set_model_state',SetModelState)
        self.model_state_req = SetModelStateRequest()
        self.model_state_req.model_state = ModelState()
        self.model_state_req.model_state.model_name = 'igor'
        self.model_state_req.model_state.pose.position.x = 0.0
        self.model_state_req.model_state.pose.position.y = 0.0
        self.model_state_req.model_state.pose.position.z = 0.861
        self.model_state_req.model_state.pose.orientation.x = 0.0
        self.model_state_req.model_state.pose.orientation.y = 0.0
        self.model_state_req.model_state.pose.orientation.z = 0.0
        self.model_state_req.model_state.pose.orientation.w = 1.0   # 0.0
        self.model_state_req.model_state.twist.linear.x = 0.0
        self.model_state_req.model_state.twist.linear.y = 0.0
        self.model_state_req.model_state.twist.linear.z = 0.0
        self.model_state_req.model_state.twist.angular.x = 0.0
        self.model_state_req.model_state.twist.angular.y = 0.0
        self.model_state_req.model_state.twist.angular.z = 0.0
        self.model_state_req.model_state.reference_frame = 'world'  

        self.joint_name_lst = ['L_hfe_joint', 'L_kfe_joint', 'L_wheel_joint', 'R_hfe_joint', 'R_kfe_joint', 'R_wheel_joint']
        self.starting_pos = np.array([0.329, -0.65, 0.0, 0.329, -0.65, 0.0])
        self.model_config_proxy = rospy.ServiceProxy('/gazebo/set_model_configuration',SetModelConfiguration)
        self.model_config_req = SetModelConfigurationRequest()
        self.model_config_req.model_name = 'igor'
        self.model_config_req.urdf_param_name = 'robot_description'
        self.model_config_req.joint_names = self.joint_name_lst
        self.model_config_req.joint_positions = self.starting_pos

        self.pause_proxy = rospy.ServiceProxy('/gazebo/pause_physics',Empty)
        self.unpause_proxy = rospy.ServiceProxy('/gazebo/unpause_physics',Empty)

        rospy.Subscriber('/igor/igor_state', Float32MultiArray, self.StateCallback, queue_size=5)
       
    def StateCallback(self, msg):
        self.robot_position[0] = msg.data[0]
        self.robot_position[1] = msg.data[1]
        self.robot_orientation = msg.data[2]
        self.current_time_velocity[0] = msg.data[3]
        self.current_time_velocity[1] = msg.data[4]
        self._lean_angle = msg.data[5]


    def set_initial_robot_state(self):
        self.current_step = 0
        self.index_of_first_point = 0
        rospy.wait_for_service('/gazebo/pause_physics')
        try:
            self.pause_proxy()
        except rospy.ServiceException:
            print('/gazebo/pause_physics service call failed')

        #set models pos from world
        init_robot_pose = np.random.random(3)
        init_robot_pose[0] = init_robot_pose[0] * 2.0 - 1.0
        init_robot_pose[1] = init_robot_pose[1] * 2.0 - 1.0
        init_robot_pose[2] = (init_robot_pose[2] * 2.0 - 1.0) * np.pi

        euler3d = np.array([0.0, 0.0, init_robot_pose[2]])
        c_euler = np.cos(euler3d)
        s_euler = np.sin(euler3d)
        w = c_euler[0] * c_euler[1] * c_euler[2] + s_euler[0] * s_euler[1] * s_euler[2]
        x = s_euler[0] * c_euler[1] * c_euler[2] - c_euler[0] * s_euler[1] * s_euler[2]
        y = c_euler[0] * s_euler[1] * c_euler[2] + s_euler[0] * c_euler[1] * s_euler[2]
        z = c_euler[0] * c_euler[1] * s_euler[2] - s_euler[0] * s_euler[1] * c_euler[2]

        self.model_state_req.model_state.pose.orientation.x = x
        self.model_state_req.model_state.pose.orientation.y = y
        self.model_state_req.model_state.pose.orientation.z = z
        self.model_state_req.model_state.pose.orientation.w = w

        self.model_state_req.model_state.pose.position.x = init_robot_pose[0]
        self.model_state_req.model_state.pose.position.y = init_robot_pose[1]

        rospy.wait_for_service('/gazebo/set_model_state')
        try:
            self.model_state_proxy(self.model_state_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_state call failed')

        #set model's joint config
        rospy.wait_for_service('/gazebo/set_model_configuration')
        try:
            self.model_config_proxy(self.model_config_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_configuration call failed')
     
        #unpause physics
        rospy.wait_for_service('/gazebo/unpause_physics')
        try:
            self.unpause_proxy()
        except rospy.ServiceException:
            print('/gazebo/unpause_physics service call failed')        
    
    def igor_lean_ok(self):
        lean_ok = True
        if abs(self._lean_angle) > np.pi / 10:
            lean_ok = False
        return lean_ok

    def calculate_total_reward(self):
        r1 = -self.weight_lean_angle_reward * self._lean_angle
        r2 = -self.weight_d * abs(self.e_d) - self.weight_theta * abs(self.e_theta)
        reward = r1 + r2
        return reward

    def get_observations(self):
        self.e_theta = -(self.line_angle - self.robot_orientation)
        self.e_d = -(self.k_line * self.robot_position[0] + self.b_line - self.robot_position[1]) \
                    / (math.sqrt(1 + self.k_line * self.k_line))
        error_state = np.array([self.e_theta, self.e_d])
        if (self.current_step == 0):
            self.last_time_velocity = self.current_time_velocity
       
        observation_return = np.append(error_state, self.last_time_velocity[1])
        self.last_time_velocity = self.current_time_velocity
        return observation_return


    def process_data(self):
        done = False
        info = ""

        lean_ok = self.igor_lean_ok()
        rospy.logdebug("igor_lean_ok=" + str(lean_ok))
        if (lean_ok == False):
            done = True
            info ="lean_failure"
            print(info + ' at step: ' + str(self.current_step))
            return self._lean_failure_reward, done, info

        reward = self.calculate_total_reward()
        # print(self.d_c)
        self.current_step = self.current_step + 1
        # print(self.current_step)

        return reward, done, info
