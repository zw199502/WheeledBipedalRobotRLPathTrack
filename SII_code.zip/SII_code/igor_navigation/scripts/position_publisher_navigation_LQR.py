#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist


class PositionPub():
    def __init__(self):
        self.cmd_pos = rospy.Publisher('/igor/commands/position', Twist, queue_size=1)
        self.init_pos_state = [0.0, 0.0]

    def set_init_position_state(self):
        self.pub_pos(self.init_pos_state, True)

    def pub_pos(self, pos_state_array, _reset=False):
        move_cmd = Twist()
        move_cmd.linear.x = pos_state_array[0]
        move_cmd.angular.z = pos_state_array[1]
        if _reset:
            move_cmd.linear.z = 0.1
        else:
            move_cmd.linear.z = -0.1
        self.cmd_pos.publish(move_cmd)
       