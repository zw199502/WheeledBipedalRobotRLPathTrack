#!/usr/bin/env python

import rospy
import copy
from std_srvs.srv import Empty
from std_msgs.msg import Float32MultiArray
from gazebo_msgs.srv import SetModelState, SetModelStateRequest, GetModelState, GetModelStateRequest, SetModelConfiguration, SetModelConfigurationRequest
from gazebo_msgs.msg import ContactsState
from gazebo_msgs.msg import ModelState
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, Vector3
import numpy
import math

import message_filters
from sensor_msgs.msg import Imu

class IgorState(object):

    def __init__(self):
        rospy.logdebug("Starting igorState Class object...")
        
        self.position_state_dim = 2
        self.velocity_state_dim = 2

        # init_target_position: world frame
        self.init_target_position = numpy.zeros(self.position_state_dim)
        self.init_target_orientation = 0.0
        # robot_position: world frame
        self.robot_position = numpy.zeros(self.position_state_dim)
        # robot_orientation: world frame
        self.robot_orientation = 0.0
       
        # current target_position: robot frame
        self.target_position = numpy.array([1.0, 1.0])
        self.target_orientation = 0.0
        self.current_target_position = numpy.array([1.0, 1.0])
        self.current_target_orientaion = 0.0

        self.current_time_velocity = numpy.zeros(self.velocity_state_dim)
        self.last_time_velocity = numpy.zeros(self.velocity_state_dim)

        self.current_step = 0
        self.episode_steps = 1000

        self.d_theta = 0.0
        self.d_c = 0.0
        self.max_d = 2.0

        self._lean_angle = 0.0

        self._arrive_reward = 100
        self._lean_failure_reward = -500
        self.r_orientation = 5.0
        self.r_distance = 1.0

        self.get_state_service = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
        self.model = GetModelStateRequest()
        self.model.model_name = 'igor'
        self.base_orientation = Quaternion()
        
        self.model_state_proxy = rospy.ServiceProxy('/gazebo/set_model_state',SetModelState)
        self.model_state_req = SetModelStateRequest()
        self.model_state_req.model_state = ModelState()
        self.model_state_req.model_state.model_name = 'igor'
        self.model_state_req.model_state.pose.position.x = 0.0
        self.model_state_req.model_state.pose.position.y = 0.0
        self.model_state_req.model_state.pose.position.z = 0.861
        self.model_state_req.model_state.pose.orientation.x = 0.0
        self.model_state_req.model_state.pose.orientation.y = 0.0
        self.model_state_req.model_state.pose.orientation.z = 0.0
        self.model_state_req.model_state.pose.orientation.w = 1.0   # 0.0
        self.model_state_req.model_state.twist.linear.x = 0.0
        self.model_state_req.model_state.twist.linear.y = 0.0
        self.model_state_req.model_state.twist.linear.z = 0.0
        self.model_state_req.model_state.twist.angular.x = 0.0
        self.model_state_req.model_state.twist.angular.y = 0.0
        self.model_state_req.model_state.twist.angular.z = 0.0
        self.model_state_req.model_state.reference_frame = 'world'  

        self.joint_name_lst = ['L_hfe_joint', 'L_kfe_joint', 'L_wheel_joint', 'R_hfe_joint', 'R_kfe_joint', 'R_wheel_joint']
        self.starting_pos = numpy.array([0.329, -0.65, 0.0, 0.329, -0.65, 0.0])
        self.model_config_proxy = rospy.ServiceProxy('/gazebo/set_model_configuration',SetModelConfiguration)
        self.model_config_req = SetModelConfigurationRequest()
        self.model_config_req.model_name = 'igor'
        self.model_config_req.urdf_param_name = 'robot_description'
        self.model_config_req.joint_names = self.joint_name_lst
        self.model_config_req.joint_positions = self.starting_pos

        self.pause_proxy = rospy.ServiceProxy('/gazebo/pause_physics',Empty)
        self.unpause_proxy = rospy.ServiceProxy('/gazebo/unpause_physics',Empty)

        rospy.Subscriber('/igor/igor_state', Float32MultiArray, self.StateCallback, queue_size=5)
       
    def StateCallback(self, msg):
        self.robot_position[0] = msg.data[0]
        self.robot_position[1] = msg.data[1]
        self.robot_orientation = msg.data[2]
        self.current_time_velocity[0] = msg.data[3]
        self.current_time_velocity[1] = msg.data[4]
        self._lean_angle = msg.data[5]

    def set_initial_robot_state(self):
        self.current_step = 0
        rospy.wait_for_service('/gazebo/pause_physics')
        try:
            self.pause_proxy()
        except rospy.ServiceException:
            print('/gazebo/pause_physics service call failed')

        #set models pos from world
        rospy.wait_for_service('/gazebo/set_model_state')
        try:
            self.model_state_proxy(self.model_state_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_state call failed')

        #set model's joint config
        rospy.wait_for_service('/gazebo/set_model_configuration')
        try:
            self.model_config_proxy(self.model_config_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_configuration call failed')
     
        #unpause physics
        rospy.wait_for_service('/gazebo/unpause_physics')
        try:
            self.unpause_proxy()
        except rospy.ServiceException:
            print('/gazebo/unpause_physics service call failed')

        # self.target_position = numpy.random.random(2) * 2.0 - 1.0

    def init_current_target_position(self):
        # print('target_position', self.target_position)
        s_theta = math.sin(self.robot_orientation)
        c_theta = math.cos(self.robot_orientation)
        self.init_target_position[0] = self.robot_position[0] + self.target_position[0] * c_theta - \
                                                                self.target_position[1] * s_theta
        self.init_target_position[1] = self.robot_position[1] + self.target_position[0] * s_theta + \
                                                                self.target_position[1] * c_theta
        self.init_target_orientation = self.robot_orientation + self.target_orientation
        
    
    def igor_lean_ok(self):
        lean_ok = True
        if numpy.abs(self._lean_angle) > numpy.pi / 10:
            lean_ok = False
        return lean_ok

    def target_arrival_ok(self):
        arrival_ok = True
        if self.d_c >= 0.05:
            arrival_ok = False
        return arrival_ok


    def calculate_total_reward(self):
        # reward = -(self.r_distance * self.d_c + self.r_orientation * self.d_theta)
        if self.target_arrival_ok():
            reward = self._arrive_reward
        else:
            return -1
            # reward = - self.d_c
            # reward = - (self.d_c + self.d_theta)
              
        return reward

    def get_observations(self):
        dx = self.init_target_position[0] - self.robot_position[0]
        dy = self.init_target_position[1] - self.robot_position[1]
        s_theta = math.sin(self.robot_orientation)
        c_theta = math.cos(self.robot_orientation)
        self.current_target_position[0] = dx * c_theta + dy * s_theta
        self.current_target_position[1] = -dx * s_theta + dy * c_theta
        self.current_target_orientaion = self.init_target_orientation - self.robot_orientation

        if (self.current_step == 0):
            self.last_time_velocity = self.current_time_velocity
        self.d_c = numpy.sqrt(numpy.power(self.current_target_position[0,], 2) + \
                        numpy.power(self.current_target_position[1,], 2))
        self.d_theta = numpy.abs(self.current_target_orientaion)
        obs = numpy.zeros(5)
        obs[0:2] = self.current_target_position
        obs[2] = self.current_target_orientaion
        obs[3:5] = self.last_time_velocity
        observation_return = numpy.append(self.current_target_position, self.last_time_velocity)
        self.last_time_velocity = self.current_time_velocity
        return observation_return


    def process_data(self):
        done = False
        info = ""

        lean_ok = self.igor_lean_ok()
        rospy.logdebug("igor_lean_ok=" + str(lean_ok))
        if (lean_ok == False):
            done = True
            info ="lean_failure"
            print(info + ' at step: ' + str(self.current_step))
            return self._lean_failure_reward, done, info

        arrival_ok = self.target_arrival_ok()
        rospy.logdebug("target_arrival_ok=" + str(self.current_step))
        if arrival_ok:
            done = True
            info = 'target_arrival_ok'
            print(info + ' at step: ' + str(self.current_step))

        if (self.current_step >= self.episode_steps):
            done = True
            info = "max_step"
            print(info + ' arrived')

        reward = self.calculate_total_reward()
        # print(self.d_c)
        self.current_step = self.current_step + 1
        # print(self.current_step)

        return reward, done, info
