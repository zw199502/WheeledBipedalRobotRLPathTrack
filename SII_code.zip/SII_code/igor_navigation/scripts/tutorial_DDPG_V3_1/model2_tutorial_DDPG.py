"""
Deep Deterministic Policy Gradient (DDPG)
-----------------------------------------
An algorithm concurrently learns a Q-function and a policy.
It uses off-policy data and the Bellman equation to learn the Q-function,
and uses the Q-function to learn the policy.

Reference
---------
Deterministic Policy Gradient Algorithms, Silver et al. 2014
Continuous Control With Deep Reinforcement Learning, Lillicrap et al. 2016
MorvanZhou's tutorial page: https://morvanzhou.github.io/tutorials/

Environment
-----------
Openai Gym Pendulum-v0, continual action space

Prerequisites
-------------
tensorflow >=2.0.0a0
tensorflow-proactionsbility 0.6.0
tensorlayer >=2.0.0

To run
------
python tutorial_DDPG.py --train/test

"""
import os
import sys

import argparse
import time
from time import time as _time


import numpy as np
import tensorflow as tf
import math

import tensorlayer as tl

from components.configuration import Igor2Config
from components.igor import Igor
from components.straight_line_following import IgorState

from threading import Lock, Condition, Thread
import threading
from sdl2 import *
from ctypes import c_char_p

# ------------------------------------------------------------------------------
# Add the root folder of the repository to the search path for modules
root_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path = [root_path] + sys.path


# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# getch API
# ------------------------------------------------------------------------------

class _Getch:
    def __init__(self):
        self.impl = _GetchUnix()
    def wait_for_next(self): 
        self.impl.wait_for_next()

class _GetchUnix:
    def __init__(self):
        import select
        from termios import tcgetattr, tcsetattr, TCSADRAIN, ICANON, ECHO, TCSAFLUSH
        from tty import setcbreak, setraw

        self._kbhit_nb = lambda: select.select([sys.stdin], [], [], 0)[0] != []
        self._kbhit = lambda: select.select([sys.stdin], [], [])[0]
        self._getch = lambda: sys.stdin.read(1)
        try:
            old_settings = tcgetattr(sys.stdin.fileno())

            term_attrs = tcgetattr(sys.stdin.fileno())
            term_attrs[3] = (term_attrs[3] & ~ICANON & ~ECHO)
            tcsetattr(sys.stdin.fileno(), TCSAFLUSH, term_attrs)
        except Exception:
            pass

        def push_terminal_unbuffered(term_attrs):
            term_attrs[3] = (term_attrs[3] & ~ICANON & ~ECHO)
            tcsetattr(sys.stdin.fileno(), TCSAFLUSH, term_attrs)


        self._get_terminal_settings = lambda: tcgetattr(sys.stdin.fileno())
        self._push_terminal_unbuffered = push_terminal_unbuffered
        self._pop_terminal_unbuffered = lambda term_attrs: tcsetattr(sys.stdin.fileno(), TCSAFLUSH, term_attrs)
        self._push_terminal_raw = lambda: setcbreak(sys.stdin.fileno())
        self._pop_terminal_raw = lambda settings: tcsetattr(sys.stdin.fileno(), TCSAFLUSH, settings)


    def wait_for_next(self):
        self._push_terminal_unbuffered(self._get_terminal_settings())
        self._kbhit()

def __dispatch_keydown_event(key_str):
    event = SDL_Event()
    event.type = SDL_KEYDOWN
    event.timestamp = _time() # TODO: Do we need to do this?
    event.state = SDL_PRESSED
    key_ctypes = c_char_p(bytes(key_str, "utf8"))
    key_code = SDL_GetKeyFromName(key_ctypes)
    scan_code = SDL_GetScancodeFromName(key_ctypes)

    event.key.keysym.scancode = scan_code
    event.key.keysym.sym = key_code
    # TODO: event.mod ?

def DDPG_test():
    global episode_reward
    global CURRENT_STEP
    global knee_velocity
    global yaw_velocity
    global directional_velocity
    global action
    DDPG_cvar.acquire()
    state, pitch = state_obj.get_observations()
    reward = state_obj.process_data()
    DDPG_cvar.release()
    
    for k in range(state_dim):
        state_record[CURRENT_STEP, k] = state[k]

    # for model two
    if CURRENT_STEP % 10 == 0:
        action = agent.get_action(state)
        action = action + action_range # control_gain > 0
    state_after_action = state
    e_theta = state_after_action[0]
    e_d = state_after_action[1]
    yaw_velocity = -action[0] * e_d * math.sin(e_theta) / e_theta - action[1] * e_theta
    if yaw_velocity > 0.6:
        yaw_velocity = 0.6
    if yaw_velocity < -0.6:
        yaw_velocity = -0.6
    directional_velocity = 0.1
    igor._chassis.set_directional_velocity(directional_velocity)
    igor._chassis.set_yaw_velocity(yaw_velocity)
    action_record[CURRENT_STEP, 0] = action[0]
    action_record[CURRENT_STEP, 1] = action[1]
    pitch_record[CURRENT_STEP, 0] = pitch
    time_record[CURRENT_STEP, 0] = time.time() - t_start

    if CURRENT_STEP > 0:
        episode_reward += reward
    if CURRENT_STEP % 10 == 0:
        print(state, action)
    CURRENT_STEP = CURRENT_STEP + 1
    if CURRENT_STEP == MAX_STEPS:
        file1 = file_prefix + 'action.txt'
        file2 = file_prefix + 'state.txt'
        file3 = file_prefix + 'pitch.txt'
        file4 = file_prefix + 'time.txt'
        np.savetxt(file1, action_record)
        np.savetxt(file2, state_record)
        np.savetxt(file3, pitch_record)
        np.savetxt(file4, time_record)
        print('Episode Reward: ', episode_reward)
        igor.request_stop()
        sys.exit(0)
        return
    
    my_timer = threading.Timer(running_step, DDPG_test)
    my_timer.start()

def __get_char_background_proc():
    global __current_char
    global knee_velocity
    global yaw_velocity
    global directional_velocity
    while True:
        _getch.wait_for_next()
        __current_char_cvar.acquire()
       
        ch = _getch.impl._getch()
        __current_char = ch
        if __current_char == 'o': # start to run model from idle mode
            igor._transition_from_idle_to_running()
            print('run mode')

        if __current_char =='k': # enable balance control
            igor.set_balance_controller_state(True) 
            print('balance control enabled')

        if __current_char =='l': # disable balance control
            igor.set_balance_controller_state(False) 
            print('balance control disabled')

        if __current_char == 'q': # increase knee velocity
            knee_velocity = knee_velocity + 0.1
            if knee_velocity > max_knee_velocity:
                knee_velocity = max_knee_velocity
            igor._left_leg.set_knee_velocity(-knee_velocity)
            igor._right_leg.set_knee_velocity(-knee_velocity)
            print('knee_velocity: ', knee_velocity)
        if __current_char == 'a': # decrease knee velocity
            knee_velocity = knee_velocity - 0.1
            if knee_velocity < -max_knee_velocity:
                knee_velocity = -max_knee_velocity
            igor._left_leg.set_knee_velocity(-knee_velocity)
            igor._right_leg.set_knee_velocity(-knee_velocity)
            print('knee_velocity: ', knee_velocity)

        if __current_char == 'w': # increase directional velocity
            directional_velocity = directional_velocity + 0.05
            if directional_velocity > max_directional_velocity:
                directional_velocity = max_directional_velocity
            igor._chassis.set_directional_velocity(directional_velocity)
            print('directional_velocity: ', directional_velocity)
        if __current_char == 's': # decrease directional velocity
            directional_velocity = directional_velocity - 0.05
            if directional_velocity < -max_directional_velocity:
                directional_velocity = -max_directional_velocity
            igor._chassis.set_directional_velocity(directional_velocity)
            print('directional_velocity: ', directional_velocity)

        # clockwise ==> negetive
        # counterclockwise ==> positive
        if __current_char == 'e': # increase yaw velocity
            yaw_velocity = yaw_velocity - 0.1
            if yaw_velocity < -max_yaw_velocity:
                yaw_velocity = -max_yaw_velocity
            igor._chassis.set_yaw_velocity(yaw_velocity)
            print('yaw_velocity: ', yaw_velocity)
        if __current_char == 'd': # decrease yaw velocity
            yaw_velocity = yaw_velocity + 0.1
            if yaw_velocity > max_yaw_velocity:
                yaw_velocity = max_yaw_velocity
            igor._chassis.set_yaw_velocity(yaw_velocity)
            print('yaw_velocity: ', yaw_velocity) 

        if __current_char == 'n': # RL test
            global agent
            agent.load()
            my_timer = threading.Timer(running_step, DDPG_test)
            my_timer.start()
            global t_start 
            t_start = time.time()
            print('RL test start')
            

        if __current_char == '0':
            igor.request_stop()
            break

        __current_char = ''
        __dispatch_keydown_event(ch)
        __current_char_cvar.notify_all()
        __current_char_cvar.release()


###############################  DDPG  ####################################
class DDPG(object):
    """
    DDPG class
    """

    def __init__(self, action_dim, state_dim, action_range):
        self.memory = np.zeros((MEMORY_CAPACITY, state_dim * 2 + action_dim + 1), dtype=np.float32)
        self.pointer = 0
        self.action_dim, self.state_dim, self.action_range = action_dim, state_dim, action_range
        self.var = action_range

        W_init = tf.random_normal_initializer(mean=0, stddev=0.3)
        b_init = tf.constant_initializer(0.1)

        def get_actor(input_state_shape, name=''):
            """
            Build actor network
            :param input_state_shape: state
            :param name: name
            :return: act
            """
            input_layer = tl.layers.Input(input_state_shape, name='A_input')
            layer = tl.layers.Dense(n_units=64, act=tf.nn.relu, W_init=W_init, b_init=b_init, name='A_l1')(input_layer)
            layer = tl.layers.Dense(n_units=64, act=tf.nn.relu, W_init=W_init, b_init=b_init, name='A_l2')(layer)
            layer = tl.layers.Dense(n_units=action_dim, act=tf.nn.tanh, W_init=W_init, b_init=b_init, name='A_a')(layer)
            layer = tl.layers.Lambda(lambda x: action_range * x)(layer)
            return tl.models.Model(inputs=input_layer, outputs=layer, name='Actor' + name)

        def get_critic(input_state_shape, input_action_shape, name=''):
            """
            Build critic network
            :param input_state_shape: state
            :param input_action_shape: act
            :param name: name
            :return: Q value Q(s,a)
            """
            state_input = tl.layers.Input(input_state_shape, name='C_s_input')
            action_input = tl.layers.Input(input_action_shape, name='C_a_input')
            layer = tl.layers.Concat(1)([state_input, action_input])
            layer = tl.layers.Dense(n_units=64, act=tf.nn.relu, W_init=W_init, b_init=b_init, name='C_l1')(layer)
            layer = tl.layers.Dense(n_units=64, act=tf.nn.relu, W_init=W_init, b_init=b_init, name='C_l2')(layer)
            layer = tl.layers.Dense(n_units=1, W_init=W_init, b_init=b_init, name='C_out')(layer)
            return tl.models.Model(inputs=[state_input, action_input], outputs=layer, name='Critic' + name)

        self.actor = get_actor([None, state_dim])
        self.critic = get_critic([None, state_dim], [None, action_dim])
        self.actor.train()
        self.critic.train()

        def copy_para(from_model, to_model):
            """
            Copy parameters for soft updating
            :param from_model: latest model
            :param to_model: target model
            :return: None
            """
            for i, j in zip(from_model.trainable_weights, to_model.trainable_weights):
                j.assign(i)

        self.actor_target = get_actor([None, state_dim], name='_target')
        copy_para(self.actor, self.actor_target)
        self.actor_target.eval()

        self.critic_target = get_critic([None, state_dim], [None, action_dim], name='_target')
        copy_para(self.critic, self.critic_target)
        self.critic_target.eval()

        self.ema = tf.train.ExponentialMovingAverage(decay=1 - TAU)  # soft replacement

        self.actor_opt = tf.optimizers.Adam(LR_A)
        self.critic_opt = tf.optimizers.Adam(LR_C)

    def get_action(self, s):
        """
        Choose action
        :param s: state
        :param greedy: get action greedy or not
        :return: act
        """
        a = self.actor(np.array([s], dtype=np.float32))[0]
        return a
    
    def load(self):
        """
        load trained weights
        :return: None
        """
        path = '/home/zw/hebi-python-examples/kits/igor2/components/model2/DDPG_igor/'
        tl.files.load_hdf5_to_weights_in_order(path + 'actor.hdf5', self.actor)
        tl.files.load_hdf5_to_weights_in_order(path + 'actor_target.hdf5', self.actor_target)
        tl.files.load_hdf5_to_weights_in_order(path + 'critic.hdf5', self.critic)
        tl.files.load_hdf5_to_weights_in_order(path + 'critic_target.hdf5', self.critic_target)

def stop_running_callback():
    global keep_running
    keep_running = False

if __name__ == '__main__':

    # ------------------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------------------
    imitation = False
    igor_config = Igor2Config(imitation)

    # ------------------------------------------------------------------------------
    # Running
    # ------------------------------------------------------------------------------
    igor = Igor(config=igor_config)
    keep_running = True

    igor.add_on_stop_callback(stop_running_callback)
    igor.start()
    igor.allow_transition_to_idle(True)

    

    # Singleton
    _getch = _Getch()
    __current_char_lock = Lock()
    __current_char_cvar = Condition(__current_char_lock)
    __current_char = None

    __current_char_proc_thread = Thread(target=__get_char_background_proc)
    __current_char_proc_thread.start()

    knee_velocity = 0.0
    max_knee_velocity = 0.6
    directional_velocity = 0.0
    max_directional_velocity = 0.3
    yaw_velocity = 0.0
    max_yaw_velocity = 0.6

    # thread for getting robot states
    state_obj = IgorState()
    # DDPG thread for test
    # add arguments in command  --train/test
    parser = argparse.ArgumentParser(description='Train or test neural net motor controller.')
    args = parser.parse_args()

    #####################  hyper parameters  ####################
    MAX_STEPS = 600  # total number of steps for each episode
    CURRENT_STEP = 0

    LR_A = 0.001  # learning rate for actor
    LR_C = 0.002  # learning rate for critic
    GAMMA = 0.9  # reward discount
    TAU = 0.01  # soft replacement
    MEMORY_CAPACITY = 10000  # size of replay buffer
    BATCH_SIZE = 32  # update action batch size

    # for model two
    state_dim = 3
    action_dim = 2
    action_range = 1.0   # scale action, [-action_range, action_range]
    running_step = 0.05

    state_record = np.zeros((MAX_STEPS, state_dim), dtype=np.float64)
    action_record = np.zeros((MAX_STEPS, action_dim), dtype=np.float64)
    pitch_record = np.zeros((MAX_STEPS, 1), dtype=np.float64)
    time_record = np.zeros((MAX_STEPS, 1), dtype=np.float64)

    action = np.zeros(action_dim)

    episode_reward = 0
    t_start = time.time()
    file_prefix = 'first_test_'

    agent = DDPG(action_dim, state_dim, action_range)
    DDPG_lock = Lock()
    DDPG_cvar = Condition(DDPG_lock)

    from time import sleep
    while keep_running:
        sleep(1.0)
