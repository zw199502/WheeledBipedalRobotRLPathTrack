#!/usr/bin/env python

import rospy

from std_srvs.srv import Empty
from std_msgs.msg import Float32MultiArray
from gazebo_msgs.srv import SetModelState, SetModelStateRequest, GetModelState, GetModelStateRequest, SetModelConfiguration, SetModelConfigurationRequest

from gazebo_msgs.msg import ModelState

from geometry_msgs.msg import Quaternion
import numpy as np
import math
import random
import threading

from sensor_msgs.msg import LaserScan

class IgorState(object):

    def __init__(self):


        # robot_position: world frame
        self.robot_position = np.zeros(2, dtype=np.float32)
        # robot_orientation: world frame
        self.robot_orientation = 0.0
        # target_position: world frame
        self.target_position_set = np.array([
                                             [1.0, 1.0], 
                                             [1.0, -1.0],
                                             [-1.0, 1.0],
                                             [-1.0, -1.0],
                                             [2.0, 2.0],
                                             [2.0, -2.0],
                                             [-2.0, 2.0],
                                             [-2.0, -2.0],
                                             [7.0, 7.0],
                                             [5.0, 5.0],
                                             [3.0, -5.0],
                                             [-5.0, -3.0],
                                             [-6.0, 3.0],
                                             [0.0, 7.0]
                                            ], dtype=np.float32)
        self.target_postion = np.array([1.0, 1.0], dtype=np.float32)
        # target_position: robot frame
        self.target_postion_robot_frame = np.array([0.0, 0.0], dtype=np.float32)
        self.target_postion_robot_frame_last = np.array([0.0, 0.0], dtype=np.float32)

         
        self._lean_angle = 0.0
        
        self.current_time_velocity = np.zeros(2, dtype=np.float32)
        # robot states include robot velocities and target positions related to robot frame
        self.returned_robot_state = np.zeros(2, dtype=np.float32)

        self._arrival_reward = 10.0
        self._lean_failure_reward = -50.0
        self._collision_free_failure_reward = -50.0
        self._move_out_of_range_reward = -1.0
        
        self.current_step = 0

        self.get_state_service = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
        self.model = GetModelStateRequest()
        self.model.model_name = 'igor'
        self.base_orientation = Quaternion()
        
        self.model_state_proxy = rospy.ServiceProxy('/gazebo/set_model_state',SetModelState)
        self.model_state_req = SetModelStateRequest()
        self.model_state_req.model_state = ModelState()
        self.model_state_req.model_state.model_name = 'igor'
        self.model_state_req.model_state.pose.position.x = 0.0
        self.model_state_req.model_state.pose.position.y = 0.0
        self.model_state_req.model_state.pose.position.z = 0.861
        self.model_state_req.model_state.pose.orientation.x = 0.0
        self.model_state_req.model_state.pose.orientation.y = 0.0
        self.model_state_req.model_state.pose.orientation.z = 0.0
        self.model_state_req.model_state.pose.orientation.w = 1.0   # 0.0
        self.model_state_req.model_state.twist.linear.x = 0.0
        self.model_state_req.model_state.twist.linear.y = 0.0
        self.model_state_req.model_state.twist.linear.z = 0.0
        self.model_state_req.model_state.twist.angular.x = 0.0
        self.model_state_req.model_state.twist.angular.y = 0.0
        self.model_state_req.model_state.twist.angular.z = 0.0
        self.model_state_req.model_state.reference_frame = 'world'  

        self.joint_name_lst = ['L_hfe_joint', 'L_kfe_joint', 'L_wheel_joint', 'R_hfe_joint', 'R_kfe_joint', 'R_wheel_joint']
        self.starting_pos = np.array([0.329, -0.65, 0.0, 0.329, -0.65, 0.0])
        self.model_config_proxy = rospy.ServiceProxy('/gazebo/set_model_configuration',SetModelConfiguration)
        self.model_config_req = SetModelConfigurationRequest()
        self.model_config_req.model_name = 'igor'
        self.model_config_req.urdf_param_name = 'robot_description'
        self.model_config_req.joint_names = self.joint_name_lst
        self.model_config_req.joint_positions = self.starting_pos

        self.pause_proxy = rospy.ServiceProxy('/gazebo/pause_physics',Empty)
        self.unpause_proxy = rospy.ServiceProxy('/gazebo/unpause_physics',Empty)

        rospy.Subscriber('/igor/igor_state', Float32MultiArray, self.StateCallback, queue_size=5)
        # rospy.Subscriber('/scan', LaserScan, self.LaserCallback, queue_size=5)

        self.used_scans_t = np.zeros((184,), dtype=np.float32)
        self.used_scans_t_1 = np.zeros((184,), dtype=np.float32)
        self.used_scans_t_2 = np.zeros((184,), dtype=np.float32)
        self.used_scans_t_3 = np.zeros((184,), dtype=np.float32)
        self.used_scans_all = np.zeros((736,), dtype=np.float32)
        self.min_range = 3.0
        self.used_range_max = 3.0
        self.lock_laser_data = threading.Lock()
        self.state_data = threading.Lock()

        # distance reward weight
        self.weight_distance = 2.0
        # lean weight
        self.weight_lean_angle_reward = 10.0
        # min_range weight
        self.min_range_weight = 0.5

    # def LaserCallback(self, msg):
    #     all_ranges = msg.ranges
    #     self.lock_laser_data.acquire()
    #     self.used_scans_t_3 = self.used_scans_t_2
    #     self.used_scans_t_2 = self.used_scans_t_1
    #     self.used_scans_t_1 = self.used_scans_t
    #     for i in range(184):
    #         self.used_scans_t[i] = all_ranges[i + 93]
    #         # the range within self.used_range_max is used
    #         if self.used_scans_t[i] > self.used_range_max:
    #             self.used_scans_t[i] = self.used_range_max
    #     self.min_range = self.used_scans_t.min()
    #     self.used_scans_all = np.hstack((self.used_scans_t, self.used_scans_t_1, self.used_scans_t_2, self.used_scans_t_3))
    #     # print(self.used_scans_all.shape)
    #     self.lock_laser_data.release()
       
    def StateCallback(self, msg):
        self.state_data.acquire()
        self.robot_position[0] = msg.data[0]
        self.robot_position[1] = msg.data[1]
        self.robot_orientation = msg.data[2]
        dx = self.target_postion[0] - self.robot_position[0]
        dy = self.target_postion[1] - self.robot_position[1]
        c_theta = math.cos(self.robot_orientation)
        s_theta = math.sin(self.robot_orientation)
        self.target_postion_robot_frame[0] = dy * s_theta + dx * c_theta
        self.target_postion_robot_frame[1] = dy * c_theta - dx * s_theta
        self.current_time_velocity[0] = msg.data[3]
        self.current_time_velocity[1] = msg.data[4]
        self._lean_angle = msg.data[5]
        x = self.target_postion_robot_frame[0]
        y = self.target_postion_robot_frame[1]
        self.returned_robot_state[0] = math.atan2(y, x)
        self.returned_robot_state[1] = math.sqrt(x * x + y * y)
        self.state_data.release()


    def set_initial_robot_state(self):
        self.current_step = 0
        self.index_of_first_point = 0
        rospy.wait_for_service('/gazebo/pause_physics')
        try:
            self.pause_proxy()
        except rospy.ServiceException:
            print('/gazebo/pause_physics service call failed')

        # randomly select a target position
        target_pos = np.random.random(2)
        index = random.randint(0, 13)
        self.state_data.acquire()
        # self.target_postion[0] = self.target_position_set[index,0]
        # self.target_postion[1] = self.target_position_set[index,1]
        # self.target_postion[0] = (target_pos[0] - 0.5) * 6.0
        # self.target_postion[1] = (target_pos[1] - 0.5) * 6.0
        self.target_postion[0] = 0.0
        self.target_postion[1] = 0.0
        # print('target_position: ', self.target_postion)
        self.state_data.release()
        #set models pos from world
        init_robot_pose = np.random.random(3)
        # init_robot_pose[0] = (init_robot_pose[0] - 0.5)
        # init_robot_pose[1] = (init_robot_pose[1] - 0.5)
        init_robot_pose[0] = (init_robot_pose[0] - 0.5) * 2
        init_robot_pose[1] = (init_robot_pose[1] - 0.5) * 2
        init_robot_pose[2] = (init_robot_pose[2] * 2.0 - 1.0) * np.pi

        euler3d = np.array([0.0, 0.0, init_robot_pose[2]])
        c_euler = np.cos(euler3d)
        s_euler = np.sin(euler3d)
        w = c_euler[0] * c_euler[1] * c_euler[2] + s_euler[0] * s_euler[1] * s_euler[2]
        x = s_euler[0] * c_euler[1] * c_euler[2] - c_euler[0] * s_euler[1] * s_euler[2]
        y = c_euler[0] * s_euler[1] * c_euler[2] + s_euler[0] * c_euler[1] * s_euler[2]
        z = c_euler[0] * c_euler[1] * s_euler[2] - s_euler[0] * s_euler[1] * c_euler[2]

        self.model_state_req.model_state.pose.orientation.x = x
        self.model_state_req.model_state.pose.orientation.y = y
        self.model_state_req.model_state.pose.orientation.z = z
        self.model_state_req.model_state.pose.orientation.w = w

        self.model_state_req.model_state.pose.position.x = init_robot_pose[0]
        self.model_state_req.model_state.pose.position.y = init_robot_pose[1]

        rospy.wait_for_service('/gazebo/set_model_state')
        try:
            self.model_state_proxy(self.model_state_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_state call failed')

        #set model's joint config
        rospy.wait_for_service('/gazebo/set_model_configuration')
        try:
            self.model_config_proxy(self.model_config_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_configuration call failed')
     
        #unpause physics
        rospy.wait_for_service('/gazebo/unpause_physics')
        try:
            self.unpause_proxy()
        except rospy.ServiceException:
            print('/gazebo/unpause_physics service call failed')   

        reward = self.calculate_total_reward()

    def igor_move_in_range_ok(self):
        move_in_range_ok = True
        # self.state_data.acquire()
        # x = math.fabs(self.robot_position[0]) - 5.0
        # y = math.fabs(self.robot_position[1]) - 5.0
        # if x >0 or y > 0:
        #     move_in_range_ok = False
        # self.state_data.release()
        if self.current_step > 50:
            move_in_range_ok = False
        return move_in_range_ok

    def igor_arrival_ok(self):
        arrival_ok = True
        self.state_data.acquire()
        if self.returned_robot_state[1] > 0.1:
            arrival_ok = False
        self.state_data.release()
        return arrival_ok
    
    def igor_collision_free_ok(self):
        collision_free_ok = True
        self.lock_laser_data.acquire()
        if self.min_range < 0.51:
            collision_free_ok = False
        self.lock_laser_data.release()
        return collision_free_ok

    def igor_lean_ok(self):
        lean_ok = True
        self.state_data.acquire()
        if abs(self._lean_angle) > np.pi / 10:
            lean_ok = False
        self.state_data.release()
        return lean_ok

    def calculate_total_reward(self):
        self.state_data.acquire()
        r1 = -self.weight_lean_angle_reward * abs(self._lean_angle)
        r2 = -self.returned_robot_state[1] - math.fabs(self.returned_robot_state[0])
        self.state_data.release()
        self.lock_laser_data.acquire()
        # print(self.min_range)
        if self.min_range > 1.5:
            r3 = 0
        else:
            r3 = -self.min_range_weight * math.exp(-(self.min_range - 0.5))
        self.lock_laser_data.release()

        reward = r1 + r2 + r3
        return r2
        # return reward

    def get_observations(self):    
        # print(self.returned_robot_state)
        return self.returned_robot_state
        # return self.used_scans_all, self.returned_robot_state

    def process_data(self):
        done = False
        info = "ok"

        move_in_range_ok = self.igor_move_in_range_ok()
        rospy.logdebug("igor_move_in_range_ok=" + str(move_in_range_ok))
        if (move_in_range_ok == False):
            done = True
            info ="move out of the range"
            print(info + ' at step: ' + str(self.current_step))
            return self._move_out_of_range_reward, done, info

        arrival_ok = self.igor_arrival_ok()
        rospy.logdebug("igor_arrival_ok=" + str(arrival_ok))

        if (arrival_ok == True):
            done = True
            info ="target arrival"
            print(info + ' at step: ' + str(self.current_step))
            return self._arrival_reward, done, info

        lean_ok = self.igor_lean_ok()
        rospy.logdebug("igor_lean_ok=" + str(lean_ok))
        if (lean_ok == False):
            done = True
            info ="lean_failure"
            print(info + ' at step: ' + str(self.current_step))
            return self._lean_failure_reward, done, info

        # collision_free_ok = self.igor_collision_free_ok()
        # rospy.logdebug("igor_collision_free_ok=" + str(collision_free_ok))
        # if (collision_free_ok == False):
        #     done = True
        #     info ="collision_free_failure"
        #     print(info + ' at step: ' + str(self.current_step))
        #     return self._collision_free_failure_reward, done, info

        reward = self.calculate_total_reward()
        # print(self.d_c)
        self.current_step = self.current_step + 1
        # print(self.current_step)

        return reward, done, info

# rospy.init_node('scan_values')
# _laser_scan = IgorState()
# rospy.spin()
