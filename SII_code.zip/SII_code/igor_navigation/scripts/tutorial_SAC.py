""" 
Soft Actor-Critic (SAC)
------------------
Actor policy in SAC is stochastic, with off-policy training. 
And 'soft' in SAC indicates the trade-off between the entropy and expected return. 
The additional consideration of entropy term helps with more explorative policy.
And this implementation contains an automatic update for the entropy factor.
This version of Soft Actor-Critic (SAC) implementation contains 5 networks: 
2 Q net, 2 target Q net, 1 policy net.
It uses alpha loss.
Reference
---------
paper: https://arxiv.org/pdf/1812.05905.pdf
Environment
---
Openai Gym Pendulum-v0, continuous action space
https://gym.openai.com/envs/Pendulum-v0/
Prerequisites
--------------
tensorflow >=2.0.0a0
tensorflow-probability 0.6.0
tensorlayer >=2.0.0
&&
pip install box2d box2d-kengz --user
To run
------
python tutorial_SAC.py --train/test
"""

import argparse
import os
import random
import time

from velocity_publisher_navigation import VelocityPub
from local_navigation import IgorState
from std_srvs.srv import Empty

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, concatenate, Conv2D, MaxPool2D, Flatten, Reshape

import tensorflow_probability as tfp

import rospy
# from igor_env_navigation import IgorEnv

Normal = tfp.distributions.Normal

##########  GPU Config    ################
physical_devices = tf.config.experimental.list_physical_devices('GPU')
assert len(physical_devices) > 0, "Not enough GPU hardware devices available"
tf.config.experimental.set_visible_devices(physical_devices[0], 'GPU')
tf.config.experimental.set_memory_growth(physical_devices[0], True)

# from tensorflow.compat.v1 import ConfigProto
# from tensorflow.compat.v1 import InteractiveSession

# config = ConfigProto()
# config.gpu_options.allow_growth = True
# session = InteractiveSession(config=config)


# add arguments in command  --train/test
parser = argparse.ArgumentParser(description='Train or test neural net motor controller.')
parser.add_argument('--train', dest='train', action='store_true', default=True)
parser.add_argument('--test', dest='test', action='store_true', default=False)
args = parser.parse_args()

#####################  hyper parameters  ####################

ENV_ID = 'igor_navigation'  # environment id
RANDOM_SEED = 2  # random seed
RENDER = False  # render while training

# RL training
ALG_NAME = 'SAC'
TRAIN_EPISODES = 1000  # total number of episodes for training
TEST_EPISODES = 10  # total number of episodes for training
MAX_STEPS = 600  # total number of steps for each episode
EXPLORE_STEPS = 500  # 500 for random action sampling in the beginning of training

BATCH_SIZE = 64  # update batch size
UPDATE_ITR = 3  # repeated updates for single step
SOFT_Q_LR = 3e-4  # q_net learning rate
POLICY_LR = 3e-4  # policy_net learning rate
ALPHA_LR = 3e-4  # alpha learning rate
POLICY_TARGET_UPDATE_INTERVAL = 3  # delayed update for the policy network and target networks
REWARD_SCALE = 1.  # value range of reward
REPLAY_BUFFER_SIZE = 5e5  # size of the replay buffer

AUTO_ENTROPY = True  # automatically updating variable alpha for entropy

###############################  SAC  ####################################



class ReplayBuffer:
    """
    a ring buffer for storing transitions and sampling for training
    :state: (state_dim,)
    :action: (action_dim,)
    :reward: (,), scalar
    :next_state: (state_dim,)
    :done: (,), scalar (0 and 1) or bool (True and False)
    """

    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []
        self.position = 0

    def push(self, laser_state, state, action, reward, next_laser_state, next_state, done):
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = (laser_state, state, action, reward, next_laser_state, next_state, done)
        self.position = int((self.position + 1) % self.capacity)  # as a ring buffer

    def sample(self, BATCH_SIZE):
        batch = random.sample(self.buffer, BATCH_SIZE)
        laser_state, state, action, reward, next_laser_state, next_state, done = map(np.stack, zip(*batch))  # stack for each element
        """ 
        the * serves as unpack: sum(a,b) <=> batch=(a,b), sum(*batch) ;
        zip: a=[1,2], b=[2,3], zip(a,b) => [(1, 2), (2, 3)] ;
        the map serves as mapping the function on each list element: map(square, [2,3]) => [4,9] ;
        np.stack((1,2)) => array([1, 2])
        """
        return laser_state, state, action, reward, next_laser_state, next_state, done

    def __len__(self):
        return len(self.buffer)


class SoftQNetwork():
    """ the network for evaluate values of state-action pairs: Q(s,a) """

    def __init__(self, laser_dim, num_inputs, num_actions, init_w=3e-3):
        super(SoftQNetwork, self).__init__()

        self.model = self.create_model(laser_dim, num_inputs, num_actions)
        # self.model.summary()

    def create_model(self, laser_dim, num_inputs, num_actions):
        _input_shape = (laser_dim,)
        laser_input = Input(_input_shape, name='q_laser_input')
        laser_input_matrix = Reshape((4, int(laser_dim/4), 1), input_shape=_input_shape, name='q_reshape')(laser_input)
        conv1 = Conv2D(
           16,             # number of kernel
           kernel_size=[2, 2], 
           activation='relu',
           name='q_c1'   
        )(laser_input_matrix)
        pool1 = MaxPool2D(pool_size=[1, 2], name='q_p1')(conv1)
        conv2 = Conv2D(
            16,
            kernel_size=[2, 2],
            activation='relu',
            name='q_c2' 
        )(pool1)
        pool2 = MaxPool2D(pool_size=[1, 2], name='q_p2')(conv2)
        # 75 = 300 / 2 / 2
        flatten1 = Flatten(name='q_flatten')(pool2)
        dense1 = Dense(128, activation='relu', name='q_dense1')(flatten1)
        dense2 = Dense(32,  activation='relu', name='q_dense2')(dense1)

        state_input = Input((num_inputs,), name='q_state_input')
        action_input = Input((num_actions,), name='q_action_input')

        connect1 = concatenate([dense2, state_input, action_input], axis=-1)
        linear1 = Dense(128, activation='relu',   name='q1')(connect1)
        linear2 = Dense(64,  activation='relu',   name='q3')(linear1)
        linear3 = Dense(1,   activation='linear', name='q4')(linear2)
        return Model([laser_input, state_input, action_input], linear3)

    def predict(self, inputs):
        return self.model.predict(inputs)


class PolicyNetwork():
    """ the network for generating non-determinstic (Gaussian distributed) action from the state input """

    def __init__(
            self, laser_dim, num_inputs, num_actions, init_w=3e-3, log_std_min=-20, log_std_max=2
    ):
        super(PolicyNetwork, self).__init__()
        self.laser_dim = laser_dim
        self.state_dim = num_inputs
        self.num_actions = num_actions
        self.log_std_min = log_std_min
        self.log_std_max = log_std_max

        self.model = self.create_model(laser_dim, num_inputs, num_actions, init_w)
        # self.model.summary()        

    def create_model(self, laser_dim, num_inputs, num_actions, init_w):
        _input_shape = (laser_dim,)
        laser_input = Input(_input_shape, name='policy_laser_input')
        laser_input_matrix = Reshape((4, int(laser_dim/4), 1), input_shape=_input_shape, name='policy_reshape')(laser_input)
        conv1 = Conv2D(
           16,             # number of kernel
           kernel_size=[2, 2], 
           activation='relu',
           name='policy_c1'   
        )(laser_input_matrix)
        pool1 = MaxPool2D(pool_size=[1, 2], name='policy_p1')(conv1)
        conv2 = Conv2D(
            16,
            kernel_size=[2, 2],
            activation='relu',
            name='policy_c2' 
        )(pool1)
        pool2 = MaxPool2D(pool_size=[1, 2], name='policy_p2')(conv2)
        # 75 = 300 / 2 / 2
        flatten1 = Flatten(name='policy_flatten')(pool2)
        dense1 = Dense(128, activation='relu', name='policy_dense1')(flatten1)
        dense2 = Dense(32,  activation='relu', name='policy_dense2')(dense1)

        state_input = Input((num_inputs,), name='policy_state_input')

        connect1 = concatenate([dense2, state_input], axis=-1)
        linear1 = Dense(128, activation='relu', name='policy1')(connect1)
        linear2 = Dense(64,  activation='relu', name='policy3')(linear1)
        linear3 = Dense(32,  activation='relu', name='policy4')(linear2)

        mean_linear = Dense(
            num_actions,
            activation='tanh',
            bias_initializer=tf.random_uniform_initializer(-init_w, init_w), 
            name='policy_mean'
        )(linear3)
        log_std_linear = Dense(
            num_actions,
            activation='softplus',   #  softplus means log( exp(features) + 1)
            bias_initializer=tf.random_uniform_initializer(-init_w, init_w),
            name='policy_logstd'
        )(linear3)

        return Model([laser_input, state_input], [mean_linear, log_std_linear])

    def _predict(self, inputs):
        # print(inputs[0].shape, inputs[1].shape)
        # print(type(inputs), type(inputs[0]), type(inputs[1]))
        mean, log_std = self.model.predict(inputs)
        log_std = tf.clip_by_value(log_std, self.log_std_min, self.log_std_max)
        return mean, log_std

    def process_actions(self, _means, _log_stds, epsilon=1e-6):
        """ generate action with state for calculating gradients """
        """ no clip in evaluation, clip affects gradients flow and causes the error of gradients not provided """
        std = tf.math.exp(_log_stds)  
        normal = Normal(0, 1)
        z = normal.sample(_means.shape)
        action = tf.math.tanh(_means + std * z)  # TanhNormal distribution as actions; reparameterization trick
        # according to original paper, with an extra last term for normalizing different action range
        # "epsilon" is added in case of "1. - action**2 = 0"
        log_prob = Normal(_means, std).log_prob(_means + std * z) - tf.math.log(1. - action**2 + epsilon)
        # both dims of normal.log_prob and -log(1-a**2) are (N,dim_of_action);
        # the Normal.log_prob outputs the same dim of input features instead of 1 dim probability,
        # needs sum up across the dim of actions to get 1 dim probability; or else use Multivariate Normal.
        log_prob = tf.reduce_sum(log_prob, axis=1)[:, np.newaxis]  # expand dim as reduce_sum causes 1 dim reduced

        return action, log_prob

    def get_action(self, inputs, greedy=False):
        """ generate action with state for interaction with envronment """
        # because batch_size = 1, the shape of the original input should be changed
        inputs[0] = np.reshape(inputs[0], [1, self.laser_dim])
        inputs[1] = np.reshape(inputs[1], [1, self.state_dim])
        mean, log_std = self._predict(inputs)
        std = tf.math.exp(log_std)

        normal = Normal(0, 1)
        z = normal.sample(mean.shape)
        action = tf.math.tanh(mean + std * z)  
        # TanhNormal distribution as actions; reparameterization trick

        action = tf.math.tanh(mean) if greedy else action
        return action.numpy()[0]

    def sample_action(self, ):
        """ generate random actions for exploration """
        a = tf.random.uniform([self.num_actions], -1, 1)
        return a.numpy()


class SAC:

    def __init__(
            self, laser_dim, state_dim, action_dim, replay_buffer, SOFT_Q_LR=3e-4, POLICY_LR=3e-4,
            ALPHA_LR=3e-4
    ):
        self.laser_dim = laser_dim
        self.replay_buffer = replay_buffer
        self.action_dim = action_dim
        # initialize all networks
        self.soft_q_net1 = SoftQNetwork(laser_dim, state_dim, action_dim)
        self.soft_q_net2 = SoftQNetwork(laser_dim, state_dim, action_dim)
        self.target_soft_q_net1 = SoftQNetwork(laser_dim, state_dim, action_dim)
        self.target_soft_q_net2 = SoftQNetwork(laser_dim, state_dim, action_dim)
        self.policy_net = PolicyNetwork(laser_dim, state_dim, action_dim)

        # print(self.policy_net.model.summary())

        # tf.Variable(<initial-value>, name=<optional-name>)
        self.log_alpha = tf.Variable(0, dtype=np.float32, name='log_alpha')
        self.alpha = tf.math.exp(self.log_alpha)
    
        # initialize weights of target networks
        soft_q_net1_weights = self.soft_q_net1.model.get_weights()
        soft_q_net2_weights = self.soft_q_net2.model.get_weights()
        self.target_soft_q_net1.model.set_weights(soft_q_net1_weights)
        self.target_soft_q_net2.model.set_weights(soft_q_net2_weights)

        self.soft_q_optimizer1 = tf.keras.optimizers.Adam(SOFT_Q_LR)
        self.soft_q_optimizer2 = tf.keras.optimizers.Adam(SOFT_Q_LR)
        self.policy_optimizer = tf.keras.optimizers.Adam(POLICY_LR)
        self.alpha_optimizer = tf.keras.optimizers.Adam(ALPHA_LR)


    def target_soft_update(self, net, target_net, soft_tau):
        """ soft update the target net with Polyak averaging """
        soft_q_net_weights = net.model.get_weights()
        target_soft_q_net_weights = target_net.model.get_weights()
        for i in range(len(soft_q_net_weights)):
            target_soft_q_net_weights[i] = target_soft_q_net_weights[i] * (1.0 - soft_tau) \
                                         + soft_q_net_weights[i] * soft_tau
        target_net.model.set_weights(target_soft_q_net_weights)
        return target_net

    def update(self, batch_size, reward_scale=10., auto_entropy=True, target_entropy=-2, gamma=0.99, soft_tau=1e-2):
        """ update all networks in SAC """
        laser_state, state, action, reward, next_laser_state, next_state, done = self.replay_buffer.sample(batch_size)

        reward = reward[:, np.newaxis]  # expand dim
        done = done[:, np.newaxis]

        reward = reward_scale * (reward - np.mean(reward, axis=0)) / (
            np.std(reward, axis=0) + 1e-6
        )  # normalize with batch mean and std; plus a small number to prevent numerical problem

        # Training Q Function
        means, log_stds = self.policy_net.model([next_laser_state, next_state])
        new_next_action, next_log_prob = self.policy_net.process_actions(means, log_stds)
        _q_net1_out = self.target_soft_q_net1.model([next_laser_state, next_state, new_next_action])
        _q_net2_out = self.target_soft_q_net2.model([next_laser_state, next_state, new_next_action])
        # state value function
        target_q_min = tf.minimum(_q_net1_out, _q_net2_out) - self.alpha * next_log_prob  
        # action-state value function
        target_q_value = reward + (1 - done) * gamma * target_q_min  # if done==1, only reward
        mse = tf.keras.losses.MeanSquaredError()

        with tf.GradientTape() as q1_tape:
            # q1_tape.watch(self.soft_q_net1.model.trainable_weights)
            predicted_q_value1 = self.soft_q_net1.model([laser_state, state, action])
            assert predicted_q_value1.shape == target_q_value.shape
            q_value_loss1 = mse(target_q_value, predicted_q_value1)
            # print(type(q_value_loss1))
            # q_value_loss1 = tf.reduce_mean(tf.losses.mean_squared_error(predicted_q_value1, target_q_value))
        q1_grad = q1_tape.gradient(q_value_loss1, self.soft_q_net1.model.trainable_weights)
        # print(len(self.soft_q_net1.model.trainable_weights))
        # print(type(q1_grad)) # list
        # print(q1_grad)
        self.soft_q_optimizer1.apply_gradients(zip(q1_grad, self.soft_q_net1.model.trainable_weights))

        with tf.GradientTape() as q2_tape:
            predicted_q_value2 = self.soft_q_net2.model([laser_state, state, action])
            q_value_loss2 = mse(target_q_value, predicted_q_value2)
            # q_value_loss2 = tf.reduce_mean(tf.losses.mean_squared_error(predicted_q_value2, target_q_value))
        q2_grad = q2_tape.gradient(q_value_loss2, self.soft_q_net2.model.trainable_weights)
        self.soft_q_optimizer2.apply_gradients(zip(q2_grad, self.soft_q_net2.model.trainable_weights))

        # Training Policy Function
        with tf.GradientTape() as p_tape:
            means, log_stds = self.policy_net.model([laser_state, state])
            new_action, log_prob = self.policy_net.process_actions(means, log_stds)
            # print(type(new_action))
            q_net1_out = self.soft_q_net1.model([laser_state, state, new_action])
            q_net2_out = self.soft_q_net2.model([laser_state, state, new_action])
            predicted_new_q_value = tf.minimum(q_net1_out, q_net2_out)
            # KL Divergence
            policy_loss = tf.reduce_mean(self.alpha * log_prob - predicted_new_q_value)
        # print(policy_loss)
        p_grad = p_tape.gradient(policy_loss, self.policy_net.model.trainable_weights)
        self.policy_optimizer.apply_gradients(zip(p_grad, self.policy_net.model.trainable_weights))

        # Updating alpha w.r.t entropy
        # alpha: trade-off between exploration (max entropy) and exploitation (max Q)
        if auto_entropy is True:
            with tf.GradientTape() as alpha_tape:
                alpha_loss = -tf.reduce_mean((self.log_alpha * (log_prob + target_entropy)))
            alpha_grad = alpha_tape.gradient(alpha_loss, [self.log_alpha])
            self.alpha_optimizer.apply_gradients(zip(alpha_grad, [self.log_alpha]))
            self.alpha = tf.math.exp(self.log_alpha)
        else:  # fixed alpha
            self.alpha = 1.
            alpha_loss = 0

        # Soft update the target value nets
        self.target_soft_q_net1 = self.target_soft_update(self.soft_q_net1, self.target_soft_q_net1, soft_tau)
        self.target_soft_q_net2 = self.target_soft_update(self.soft_q_net2, self.target_soft_q_net2, soft_tau)

    def save(self):  # save trained weights
        path = os.path.join('model', '_'.join([ALG_NAME, ENV_ID]))
        if not os.path.exists(path):
            os.makedirs(path)
        extend_path = lambda s: os.path.join(path, s)
        self.soft_q_net1.model.save_weights(extend_path('model_q_net1.h5'))
        self.target_soft_q_net1.model.save_weights(extend_path('model_target_q_net1.h5'))
        self.target_soft_q_net2.model.save_weights(extend_path('model_target_q_net2.h5'))
        self.policy_net.model.save_weights(extend_path('model_policy_net.h5'))

        np.save(extend_path('log_alpha.npy'), self.log_alpha.numpy())  # save log_alpha variable

    def load_weights(self):  # load trained weights
        path = os.path.join('model', '_'.join([ALG_NAME, ENV_ID]))
        extend_path = lambda s: os.path.join(path, s)
        self.soft_q_net1.model.load_weights(extend_path('model_q_net1.h5'))
        self.target_soft_q_net1.model.load_weights(extend_path('model_target_q_net1.h5'))
        self.target_soft_q_net2.model.load_weights(extend_path('model_target_q_net2.h5'))
        self.policy_net.model.load_weights(extend_path('model_policy_net.h5'))

        self.log_alpha.assign(np.load(extend_path('log_alpha.npy')))  # load log_alpha variable

if __name__ == '__main__':
    # initialization of env
    rospy.init_node('igor_main', anonymous=True, log_level=rospy.INFO)
    unpause = rospy.ServiceProxy('/gazebo/unpause_physics', Empty)
    pause = rospy.ServiceProxy('/gazebo/pause_physics', Empty)
    laser_dim = 736
    state_dim = 4
    action_dim = 2 # linear and angular velocities

    last_action = np.zeros((action_dim,))

    running_step = 0.1 # control frequency: 10Hz
    igor_state_object = IgorState()
    igor_velocity_pubisher_object = VelocityPub()

    # reproducible
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)
    tf.random.set_seed(RANDOM_SEED)

    # initialization of buffer
    replay_buffer = ReplayBuffer(REPLAY_BUFFER_SIZE)
    # initialization of trainer
    agent = SAC(laser_dim, state_dim, action_dim, replay_buffer, SOFT_Q_LR, POLICY_LR, ALPHA_LR)

    t0 = time.time()
    # training loop
    if args.train:
        frame_idx = 0
        all_episode_reward = []
        all_episode_reward_save = np.zeros(TRAIN_EPISODES)

        for episode in range(TRAIN_EPISODES):
            # print("set_init_robot_state...")
            igor_state_object.set_initial_robot_state()
            # print("set_init_command_velocity...")
            igor_velocity_pubisher_object.set_init_velocity_state()
            rospy.sleep(3.0)
            laser_state, state = igor_state_object.get_observations()
            episode_reward = 0
            for step in range(MAX_STEPS):
                if frame_idx > EXPLORE_STEPS:
                    # time_t  = time.time()
                    action = agent.policy_net.get_action([laser_state, state], greedy=False)
                    # print('time: ', time.time() - time_t) # around 0.033s
                else:
                    action = agent.policy_net.sample_action()

                # unpause simulation
                rospy.wait_for_service('/gazebo/unpause_physics')
                try:
                    unpause()
                except (rospy.ServiceException, e):
                    print ("/gazebo/unpause_physics service call failed")

                # linear velocity range [0, 0.2]
                action[0] = (action[0] + 1.0) * 0.1
                # angular velocity range [-0.6, 0.6]
                action[1] = action[1] * 0.6
                # maximum linear acceleration 0.5
                # maximum angular acceleration 0.5
                if ((action[0] - last_action[0]) > (running_step * 0.5)):
                    action[0] = last_action[0] + running_step * 0.5
                if ((action[0] - last_action[0]) < (-running_step * 0.5)):
                    action[0] = last_action[0] - running_step * 0.5
                if ((action[1] - last_action[1]) > (running_step * 0.5)):
                    action[1] = last_action[1] + running_step * 0.5
                if ((action[1] - last_action[1]) < (-running_step * 0.5)):
                    action[1] = last_action[1] - running_step * 0.5
                igor_velocity_pubisher_object.pub_vel(action)
                rospy.sleep(running_step)
                last_action = action
                # print(rospy.get_time())

                # We now process the latest data saved in the class state to calculate
                # the state and the rewards. This way we guarantee that they work
                # with the same exact data.
                # Generate State based on observations
                next_laser_state, next_state = igor_state_object.get_observations()
                # finally we get an evaluation based on what happened in the sim
                reward, done, info = igor_state_object.process_data()
                # Pause simulation
                rospy.wait_for_service('/gazebo/pause_physics')
                try:
                    pause()
                except (rospy.ServiceException, e):
                    print ("/gazebo/pause_physics service call failed")
                done = 1 if done is True else 0

                replay_buffer.push(laser_state, state, action, reward, next_laser_state, next_state, done)
                state = next_state
                laser_state = next_laser_state
                episode_reward += reward
                frame_idx += 1

                if len(replay_buffer) > BATCH_SIZE:
                    # time_t  = time.time()
                    for i in range(UPDATE_ITR):
                        agent.update(
                            BATCH_SIZE, reward_scale=REWARD_SCALE, auto_entropy=AUTO_ENTROPY,
                            target_entropy=-1. * action_dim
                        )
                    # print('time: ', time.time() - time_t) # around 1.7s
                if done:
                    break
            if episode == 0:
                all_episode_reward.append(episode_reward)
                all_episode_reward_save[episode] = episode_reward
            else:
                all_episode_reward.append(all_episode_reward[-1] * 0.9 + episode_reward * 0.1)
                all_episode_reward_save[episode] = all_episode_reward[-1] * 0.9 + episode_reward * 0.1
            
            print(
                'Training  | Episode: {}/{}  | Episode Reward: {:.4f}  | Running Time: {:.4f}'.format(
                    episode + 1, TRAIN_EPISODES, episode_reward,
                    time.time() - t0
                )
            )
        agent.save()
        plt.plot(all_episode_reward)
        if not os.path.exists('image'):
            os.makedirs('image')
        plt.savefig(os.path.join('image', '_'.join([ALG_NAME, ENV_ID])))
        np.savetxt('all_episode_reward_save.txt', all_episode_reward_save)

    if args.test:
        agent.load_weights()
        # need an extra call here to make inside functions be able to use model.forward
    
        for episode in range(TEST_EPISODES):
            # print("set_init_robot_state...")
            igor_state_object.set_initial_robot_state()
            # print("set_init_command_velocity...")
            igor_velocity_pubisher_object.set_init_velocity_state()
            rospy.sleep(3.0)
            laser_state, state = igor_state_object.get_observations()
            episode_reward = 0
            for step in range(MAX_STEPS):
                action = agent.policy_net.get_action([laser_state, state], greedy=True)
                # linear velocity range [0, 0.2]
                action[0] = (action[0] + 1.0) * 0.1
                # angular velocity range [-0.6, 0.6]
                action[1] = action[1] * 0.6
                # maximum linear acceleration 0.5
                # maximum angular acceleration 0.5
                if ((action[0] - last_action[0]) > (running_step * 0.5)):
                    action[0] = last_action[0] + running_step * 0.5
                if ((action[0] - last_action[0]) < (-running_step * 0.5)):
                    action[0] = last_action[0] - running_step * 0.5
                if ((action[1] - last_action[1]) > (running_step * 0.5)):
                    action[1] = last_action[1] + running_step * 0.5
                if ((action[1] - last_action[1]) < (-running_step * 0.5)):
                    action[1] = last_action[1] - running_step * 0.5
                igor_velocity_pubisher_object.pub_vel(action)
                rospy.sleep(running_step)
                last_action = action
                # print(rospy.get_time())

                # We now process the latest data saved in the class state to calculate
                # the state and the rewards. This way we guarantee that they work
                # with the same exact data.
                # Generate State based on observations
                laser_state, state = igor_state_object.get_observations()

                # finally we get an evaluation based on what happened in the sim
                reward, done, info = igor_state_object.process_data()
                episode_reward += reward
                if done:
                    break
            print(
                'Testing  | Episode: {}/{}  | Episode Reward: {:.4f}  | Running Time: {:.4f}'.format(
                    episode + 1, TEST_EPISODES, episode_reward,
                    time.time() - t0
                )
            )
