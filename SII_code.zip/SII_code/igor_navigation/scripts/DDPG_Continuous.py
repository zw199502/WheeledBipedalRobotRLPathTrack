import wandb
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Lambda, concatenate, Conv2D, MaxPool2D, Flatten, Reshape

import rospy
from velocity_publisher_navigation import VelocityPub
from local_navigation import IgorState
from std_srvs.srv import Empty

import argparse
import os
import time
import numpy as np
import random
from collections import deque

tf.keras.backend.set_floatx('float32')
wandb.init(name='DDPG', project="deep-rl-tf2")

##########  file log  ##################
ALG_NAME = 'DDPG'
ENV_ID = 'igor_navigation'  # environment id

##########  GPU Config    ################
physical_devices = tf.config.experimental.list_physical_devices('GPU')
assert len(physical_devices) > 0, "Not enough GPU hardware devices available"
tf.config.experimental.set_visible_devices(physical_devices[0], 'GPU')
tf.config.experimental.set_memory_growth(physical_devices[0], True)

parser = argparse.ArgumentParser()
parser.add_argument('--gamma', type=float, default=0.99)
parser.add_argument('--actor_lr', type=float, default=0.0005)
parser.add_argument('--critic_lr', type=float, default=0.001)
parser.add_argument('--batch_size', type=int, default=64)
parser.add_argument('--tau', type=float, default=0.05)
parser.add_argument('--train_start', type=int, default=200)
parser.add_argument('--max_linear_accel', type=float, default=0.5)
parser.add_argument('--max_angular_accel', type=float, default=1.0)

args = parser.parse_args()

class ReplayBuffer:
    def __init__(self, capacity=20000):
        self.buffer = deque(maxlen=capacity)
    
    def put(self, laser_state, state, action, reward, next_laser_state, next_state, done):
        self.buffer.append([laser_state, state, action, reward, next_laser_state, next_state, done])
    
    def sample(self):
        sample = random.sample(self.buffer, args.batch_size)
        laser_states, states, actions, rewards, next_laser_states, next_states, done = map(np.asarray, zip(*sample))
        states = np.array(states).reshape(args.batch_size, -1)
        next_states = np.array(next_states).reshape(args.batch_size, -1)
        laser_states = np.array(laser_states).reshape(args.batch_size, -1)
        next_laser_states = np.array(next_laser_states).reshape(args.batch_size, -1)
        return laser_states, states, actions, rewards, next_laser_states, next_states, done
    
    def size(self):
        return len(self.buffer)

class Actor:
    def __init__(self, laser_state_dim, state_dim, action_dim, action_bound):
        self.laser_state_dim = laser_state_dim
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.action_bound = action_bound
        self.model = self.create_model()
        self.opt = tf.keras.optimizers.Adam(args.actor_lr)

    def create_model(self):
        _input_shape = (self.laser_state_dim,)
        laser_input = Input(_input_shape, name='policy_laser_input')
        laser_input_matrix = Reshape((4, int(self.laser_state_dim/4), 1), input_shape=_input_shape, 
                                      name='policy_reshape')(laser_input)
        conv1 = Conv2D(
           16,             # number of kernel
           kernel_size=[2, 2], 
           activation='relu',
           name='policy_c1'   
        )(laser_input_matrix)
        pool1 = MaxPool2D(pool_size=[1, 2], name='policy_p1')(conv1)
        conv2 = Conv2D(
            16,
            kernel_size=[2, 2],
            activation='relu',
            name='policy_c2' 
        )(pool1)
        pool2 = MaxPool2D(pool_size=[1, 2], name='policy_p2')(conv2)
        flatten1 = Flatten(name='policy_flatten')(pool2)
        dense1 = Dense(128, activation='relu', name='policy_dense1')(flatten1)
        dense2 = Dense(32,  activation='relu', name='policy_dense2')(dense1)

        state_input = Input((self.state_dim,), name='policy_state_input')

        connect1 = concatenate([dense2, state_input], axis=-1)
        linear1 = Dense(128, activation='relu', name='policy1')(connect1)
        linear2 = Dense(64,  activation='relu', name='policy2')(linear1)
        linear3 = Dense(32,  activation='relu', name='policy3')(linear2)

        out_action = Dense(self.action_dim, activation='tanh')(linear3)
        out_action = Lambda(lambda x: x * self.action_bound)(out_action)
       
        return Model([laser_input, state_input], out_action)


    def train(self, laser_states, states, q_grads):
        with tf.GradientTape() as tape:
            grads = tape.gradient(self.model([laser_states, states]), self.model.trainable_variables, -q_grads)
        self.opt.apply_gradients(zip(grads, self.model.trainable_variables))
    
    def predict(self, inputs):
        # print(state[0].shape)
        # print(type(state))
        return self.model.predict(inputs)

    def get_action(self, inputs):
        # print(state.shape)
        # print(type(state))
        inputs[0] = np.reshape(inputs[0], [1, self.laser_state_dim])
        inputs[1] = np.reshape(inputs[1], [1, self.state_dim])
        # print(state.shape)
        # print(type(state))
        return self.model.predict(inputs)[0]



class Critic:
    def __init__(self, laser_state_dim, state_dim, action_dim):
        self.laser_state_dim = laser_state_dim
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.model = self.create_model()
        self.opt = tf.keras.optimizers.Adam(args.critic_lr)

    def create_model(self):
        _input_shape = (self.laser_state_dim,)
        laser_input = Input(_input_shape, name='q_laser_input')
        laser_input_matrix = Reshape((4, int(self.laser_state_dim/4), 1), input_shape=_input_shape, name='q_reshape')(laser_input)
        conv1 = Conv2D(
           16,             # number of kernel
           kernel_size=[2, 2], 
           activation='relu',
           name='q_c1'   
        )(laser_input_matrix)
        pool1 = MaxPool2D(pool_size=[1, 2], name='q_p1')(conv1)
        conv2 = Conv2D(
            16,
            kernel_size=[2, 2],
            activation='relu',
            name='q_c2' 
        )(pool1)
        pool2 = MaxPool2D(pool_size=[1, 2], name='q_p2')(conv2)
        flatten1 = Flatten(name='q_flatten')(pool2)
        dense1 = Dense(128, activation='relu', name='q_dense1')(flatten1)
        dense2 = Dense(32,  activation='relu', name='q_dense2')(dense1)

        state_input = Input((self.state_dim,), name='q_state_input')
        action_input = Input((self.action_dim,), name='q_action_input')

        connect1 = concatenate([dense2, state_input, action_input], axis=-1)
        linear1 = Dense(128, activation='relu',   name='q1')(connect1)
        linear2 = Dense(64,  activation='relu',   name='q3')(linear1)
        out_q = Dense(1,   activation='linear', name='q4')(linear2)
        return Model([laser_input, state_input, action_input], out_q)
    
    def predict(self, inputs):
        
        return self.model.predict(inputs)
    
    def q_grads(self, laser_states, states, actions):
        actions = tf.convert_to_tensor(actions)
        with tf.GradientTape() as tape:
            tape.watch(actions)
            q_values = self.model([laser_states, states, actions])
            q_values = tf.squeeze(q_values)
        return tape.gradient(q_values, actions)

    def compute_loss(self, v_pred, td_targets):
        mse = tf.keras.losses.MeanSquaredError()
        return mse(td_targets, v_pred)

    def train(self, laser_states, states, actions, td_targets):
        with tf.GradientTape() as tape:
            v_pred = self.model([laser_states, states, actions], training=True)
            assert v_pred.shape == td_targets.shape
            loss = self.compute_loss(v_pred, tf.stop_gradient(td_targets))
            # print(type(loss))
        grads = tape.gradient(loss, self.model.trainable_variables)
        # print(grads)
        self.opt.apply_gradients(zip(grads, self.model.trainable_variables))
        return loss


class Agent:
    def __init__(self):

        self.unpause = rospy.ServiceProxy('/gazebo/unpause_physics', Empty)
        self.pause = rospy.ServiceProxy('/gazebo/pause_physics', Empty)

        self.running_step = 0.1 # control frequency: 10Hz
        self.igor_state_object = IgorState()
        self.igor_velocity_pubisher_object = VelocityPub()

        self.laser_state_dim = 736
        self.state_dim = 4
        self.action_dim = 2
        self.action_bound = 1.0

        self.buffer = ReplayBuffer()

        self.actor = Actor(self.laser_state_dim, self.state_dim, self.action_dim, self.action_bound)
        self.critic = Critic(self.laser_state_dim, self.state_dim, self.action_dim)
        # print(self.critic.model.summary())
        
        self.target_actor = Actor(self.laser_state_dim, self.state_dim, self.action_dim, self.action_bound)
        self.target_critic = Critic(self.laser_state_dim, self.state_dim, self.action_dim)

        actor_weights = self.actor.model.get_weights()
        critic_weights = self.critic.model.get_weights()
        self.target_actor.model.set_weights(actor_weights)
        self.target_critic.model.set_weights(critic_weights)
        
    
    def target_update(self):
        actor_weights = self.actor.model.get_weights()
        t_actor_weights = self.target_actor.model.get_weights()
        critic_weights = self.critic.model.get_weights()
        t_critic_weights = self.target_critic.model.get_weights()

        for i in range(len(actor_weights)):
            t_actor_weights[i] = args.tau * actor_weights[i] + (1 - args.tau) * t_actor_weights[i]

        for i in range(len(critic_weights)):
            t_critic_weights[i] = args.tau * critic_weights[i] + (1 - args.tau) * t_critic_weights[i]
        
        self.target_actor.model.set_weights(t_actor_weights)
        self.target_critic.model.set_weights(t_critic_weights)


    def td_target(self, rewards, q_values, dones):
        targets = np.asarray(q_values)
        for i in range(q_values.shape[0]):
            if dones[i]:
                targets[i] = rewards[i]
            else:
                targets[i] = args.gamma * q_values[i]
        return targets

    def list_to_batch(self, list):
        batch = list[0]
        for elem in list[1:]:
            batch = np.append(batch, elem, axis=0)
        return batch
    
    def ou_noise(self, x, rho=0.15, mu=0, dt=1e-1, sigma=0.2, dim=1):
        return x + rho * (mu-x) * dt + sigma * np.sqrt(dt) * np.random.normal(size=dim)
    
    def replay(self):
        for _ in range(10):
            laser_states, states, actions, rewards, next_laser_states, next_states, dones = self.buffer.sample()
            target_q_values = self.target_critic.predict([next_laser_states, next_states, 
                                                          self.target_actor.predict([next_laser_states, next_states])])
            td_targets = self.td_target(rewards, target_q_values, dones)
            td_targets = np.float32(td_targets)
            actions = np.float32(actions)
            self.critic.train(laser_states, states, actions, td_targets)
            
            s_actions = self.actor.predict([laser_states ,states])
            s_grads = self.critic.q_grads(laser_states, states, s_actions)
            grads = np.array(s_grads).reshape((-1, self.action_dim))
            grads = np.float32(grads)
            self.actor.train(laser_states, states, grads)
            self.target_update()

    def train(self, max_episodes=1000):
        episode_reward_save = np.zeros(max_episodes)
        for ep in range(max_episodes):
            episode_reward, done = 0, False
            # print("set_init_robot_state...")
            self.igor_state_object.set_initial_robot_state()
            # print("set_init_command_velocity...")
            self.igor_velocity_pubisher_object.set_init_velocity_state()
            rospy.sleep(3.0)
            laser_state, state = self.igor_state_object.get_observations()
    
            bg_noise = np.zeros(self.action_dim)
            while not done:
                action = self.actor.get_action([laser_state, state])
                noise = self.ou_noise(bg_noise, dim=self.action_dim)
                action = np.clip(action + noise, -self.action_bound, self.action_bound)

                # linear velocity range [0, 0.2]
                action[0] = (action[0] + 1.0) * 0.1
                # angular velocity range [-0.6, 0.6]
                action[1] = action[1] * 0.6
                # print(action)
                self.igor_velocity_pubisher_object.pub_vel(action)
                rospy.sleep(self.running_step - 0.005)

                 # Generate State based on observations
                next_laser_state, next_state = self.igor_state_object.get_observations()
                # finally we get an evaluation based on what happened in the sim
                reward, done, info = self.igor_state_object.process_data()

                self.buffer.put(laser_state, state, action, (reward+8)/8, next_laser_state, next_state, done)
                bg_noise = noise
                episode_reward += reward
                laser_state = next_laser_state
                state = next_state
                if self.buffer.size() >= args.batch_size and self.buffer.size() >= args.train_start:
                    rospy.wait_for_service('/gazebo/pause_physics')
                    try:
                        self.pause()
                    except (rospy.ServiceException, e):
                        print ("/gazebo/pause_physics service call failed")

                    self.replay()

                    # unpause simulation
                    rospy.wait_for_service('/gazebo/unpause_physics')
                    try:
                        self.unpause()
                    except (rospy.ServiceException, e):
                        print ("/gazebo/unpause_physics service call failed")   
            episode_reward_save[ep] = episode_reward   
            print('EP{} EpisodeReward={}'.format(ep, episode_reward))
            wandb.log({'Reward': episode_reward})
            if ((ep > 0) and (ep % 100 == 0)):
                np.savetxt('episode_reward.txt', episode_reward_save)
                self.save()  # save net weights

    def save(self):  # save trained weights
        path = os.path.join('model', '_'.join([ALG_NAME, ENV_ID]))
        if not os.path.exists(path):
            os.makedirs(path)
        extend_path = lambda s: os.path.join(path, s)
        self.actor.model.save_weights(extend_path('actor.h5'))
        self.critic.model.save_weights(extend_path('critic.h5'))

    def load_weights(self):  # load trained weights
        path = os.path.join('model', '_'.join([ALG_NAME, ENV_ID]))
        extend_path = lambda s: os.path.join(path, s)
        self.actor.model.load_weights(extend_path('actor.h5'))
        self.critic.model.load_weights(extend_path('critic.h5'))


def main():
    rospy.init_node('igor_main', anonymous=True, log_level=rospy.INFO)
    agent = Agent()
    agent.train()


if __name__ == "__main__":
    main()
