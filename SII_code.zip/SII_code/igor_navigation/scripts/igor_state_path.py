#!/usr/bin/env python

import rospy
import copy
from std_srvs.srv import Empty
from std_msgs.msg import Float32MultiArray
from gazebo_msgs.srv import SetModelState, SetModelStateRequest, GetModelState, GetModelStateRequest, SetModelConfiguration, SetModelConfigurationRequest
from gazebo_msgs.msg import ContactsState
from gazebo_msgs.msg import ModelState
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, Vector3
import numpy as np
import math

import message_filters
from sensor_msgs.msg import Imu

class IgorState(object):

    def __init__(self):
        # target path with N points in world frame
        self.N_points = 73
        self.target_path = np.zeros((2, self.N_points), dtype=np.float64)
        self.produce_target_path() 

        # robot_position: world frame
        self.robot_position = np.zeros(2)
        # robot_orientation: world frame
        self.robot_orientation = 0.0

        self.index_of_first_point = 0
        self.criterion_of_plus_index = 0.0025

        self.N_state_points = 5 # window size
        self.weights_N_state_points = np.array([[1.0],[0.5],[0.04],[0.003],[0.002]])
        # robot_frame
        self.points_current_window = np.zeros((2, self.N_state_points), dtype=np.float64)

        self.current_time_velocity = np.zeros(2)
        self.last_time_velocity = np.zeros(2)

        self._lean_angle = 0.0
        self.weight_lean_angle_reward = 10.0

        self._lean_failure_reward = -500
        
        self.current_step = 0

        self.get_state_service = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
        self.model = GetModelStateRequest()
        self.model.model_name = 'igor'
        self.base_orientation = Quaternion()
        
        self.model_state_proxy = rospy.ServiceProxy('/gazebo/set_model_state',SetModelState)
        self.model_state_req = SetModelStateRequest()
        self.model_state_req.model_state = ModelState()
        self.model_state_req.model_state.model_name = 'igor'
        self.model_state_req.model_state.pose.position.x = 0.0
        self.model_state_req.model_state.pose.position.y = 0.0
        self.model_state_req.model_state.pose.position.z = 0.861
        self.model_state_req.model_state.pose.orientation.x = 0.0
        self.model_state_req.model_state.pose.orientation.y = 0.0
        self.model_state_req.model_state.pose.orientation.z = 0.0
        self.model_state_req.model_state.pose.orientation.w = 1.0   # 0.0
        self.model_state_req.model_state.twist.linear.x = 0.0
        self.model_state_req.model_state.twist.linear.y = 0.0
        self.model_state_req.model_state.twist.linear.z = 0.0
        self.model_state_req.model_state.twist.angular.x = 0.0
        self.model_state_req.model_state.twist.angular.y = 0.0
        self.model_state_req.model_state.twist.angular.z = 0.0
        self.model_state_req.model_state.reference_frame = 'world'  

        self.joint_name_lst = ['L_hfe_joint', 'L_kfe_joint', 'L_wheel_joint', 'R_hfe_joint', 'R_kfe_joint', 'R_wheel_joint']
        self.starting_pos = np.array([0.329, -0.65, 0.0, 0.329, -0.65, 0.0])
        self.model_config_proxy = rospy.ServiceProxy('/gazebo/set_model_configuration',SetModelConfiguration)
        self.model_config_req = SetModelConfigurationRequest()
        self.model_config_req.model_name = 'igor'
        self.model_config_req.urdf_param_name = 'robot_description'
        self.model_config_req.joint_names = self.joint_name_lst
        self.model_config_req.joint_positions = self.starting_pos

        self.pause_proxy = rospy.ServiceProxy('/gazebo/pause_physics',Empty)
        self.unpause_proxy = rospy.ServiceProxy('/gazebo/unpause_physics',Empty)

        rospy.Subscriber('/igor/igor_state', Float32MultiArray, self.StateCallback, queue_size=5)
       
    def StateCallback(self, msg):
        self.robot_position[0] = msg.data[0]
        self.robot_position[1] = msg.data[1]
        self.robot_orientation = msg.data[2]
        self.current_time_velocity[0] = msg.data[3]
        self.current_time_velocity[1] = msg.data[4]
        self._lean_angle = msg.data[5]

    def produce_target_path(self):
        # circle path in world frame
        # polar coordinate
        # polar angle
        # theta = 0.0
        # circle diameter
        # d = 4
        # for i in range (self.N_points):
        #     s_theta = math.sin(theta / 2.0)
        #     c_theta = math.cos(theta / 2.0)
        #     self.target_path[0, i] = d * s_theta * c_theta
        #     self.target_path[1, i] = d * s_theta * s_theta
        #     theta = theta + 0.1

        # straight line
        for i in range (self.N_points):    
            self.target_path[0, i] = (i + 1) * 0.2
            self.target_path[1, i] = 0.0

    def position_robot_frame_trans(self, position):
        dx = position[0] - self.robot_position[0]
        dy = position[1] - self.robot_position[1]
        s_theta = math.sin(self.robot_orientation)
        c_theta = math.cos(self.robot_orientation)
        _position = np.zeros(2)
        _position[0] = dx * c_theta + dy * s_theta
        _position[1] = -dx * s_theta + dy * c_theta
        return _position


    def set_initial_robot_state(self):
        self.current_step = 0
        self.index_of_first_point = 0
        rospy.wait_for_service('/gazebo/pause_physics')
        try:
            self.pause_proxy()
        except rospy.ServiceException:
            print('/gazebo/pause_physics service call failed')

        #set models pos from world
        rospy.wait_for_service('/gazebo/set_model_state')
        try:
            self.model_state_proxy(self.model_state_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_state call failed')

        #set model's joint config
        rospy.wait_for_service('/gazebo/set_model_configuration')
        try:
            self.model_config_proxy(self.model_config_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_configuration call failed')
     
        #unpause physics
        rospy.wait_for_service('/gazebo/unpause_physics')
        try:
            self.unpause_proxy()
        except rospy.ServiceException:
            print('/gazebo/unpause_physics service call failed')        
    
    def igor_lean_ok(self):
        lean_ok = True
        if abs(self._lean_angle) > np.pi / 10:
            lean_ok = False
        return lean_ok

    def calculate_total_reward(self):
        r1 = -self.weight_lean_angle_reward * self._lean_angle
        r2 = 0.0
        reward = 0.0
        for i in range(self.N_state_points):
            r2 = r2 - self.weights_N_state_points[i] * (np.sum(self.points_current_window[:, i]**2))
        _r2 = r2[0]
        reward = r1 + _r2
        return reward

    def get_observations(self):
        
        position_in_robot_frame = np.zeros(2)
        if (self.index_of_first_point < (self.N_points - self.N_state_points - 1)):
            position_in_robot_frame = self.position_robot_frame_trans(self.target_path[:, self.index_of_first_point])
        while (np.sum(position_in_robot_frame**2) <= self.criterion_of_plus_index):
            if (self.index_of_first_point < (self.N_points - self.N_state_points)):
                position_in_robot_frame = self.position_robot_frame_trans(self.target_path[:, self.index_of_first_point])
            else: 
                break
            self.index_of_first_point = self.index_of_first_point + 1
        for i in range(self.N_state_points):
            self.points_current_window[:, i] = self.position_robot_frame_trans(self.target_path[:, self.index_of_first_point + i])
        if (self.current_step == 0):
            self.last_time_velocity = self.current_time_velocity
        # if self.current_step % 20 == 0:
        #     print(self.points_current_window)
        #     print(self.robot_position, self.robot_orientation)
        #     print(self.target_path[:, self.index_of_first_point: self.index_of_first_point + 5])
        observation_return = np.append(self.points_current_window.flatten(), self.last_time_velocity)
        self.last_time_velocity = self.current_time_velocity
        return observation_return


    def process_data(self):
        done = False
        info = ""

        lean_ok = self.igor_lean_ok()
        rospy.logdebug("igor_lean_ok=" + str(lean_ok))
        if (lean_ok == False):
            done = True
            info ="lean_failure"
            print(info + ' at step: ' + str(self.current_step))
            return self._lean_failure_reward, done, info

        if (self.index_of_first_point == self.N_points - self.N_state_points - 5):
            done = True
            info ="path following task finishes"
            print(info + ' at step: ' + str(self.current_step))

        reward = self.calculate_total_reward()
        # print(self.d_c)
        self.current_step = self.current_step + 1
        # print(self.current_step)

        return reward, done, info
