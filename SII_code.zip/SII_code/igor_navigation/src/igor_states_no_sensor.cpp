# include "igor_states_no_sensor.h"

igor_states_no_sensor::igor_states_no_sensor(ros::NodeHandle* nodehandle):nh_(*nodehandle) //Constructor
{
    
    body_imu_sub_  = new message_filters::Subscriber<sensor_msgs::Imu>(nh_, "/igor/body_imu/data", 1);
    L_wheel_imu_sub_  = new message_filters::Subscriber<sensor_msgs::Imu>(nh_, "/igor/L_wheel_imu/data", 1);
    R_wheel_imu_sub_  = new message_filters::Subscriber<sensor_msgs::Imu>(nh_, "/igor/R_wheel_imu/data", 1);
    joint_states_sub_ = new message_filters::Subscriber<sensor_msgs::JointState>(nh_, "/igor/joint_states", 1);
    CoG_sub_ = new message_filters::Subscriber<geometry_msgs::PointStamped>(nh_, "/cog/robot", 1);
   
    sync_ = new  message_filters::Synchronizer<SyncPolicy>(SyncPolicy(10), *body_imu_sub_,
        *L_wheel_imu_sub_,*R_wheel_imu_sub_,*joint_states_sub_,*CoG_sub_);
    sync_->registerCallback(boost::bind(&igor_states_no_sensor::combineCallback,this,_1,_2,_3,_4,_5));
    

    igor_general_state_publisher = nh_.advertise<std_msgs::Float32MultiArray>( "/igor/igor_state", 5);
    igor_state_publisher = nh_.advertise<std_msgs::Float32MultiArray>( "/igor/igor_actual_state", 5);

    get_state_service = nh_.serviceClient<gazebo_msgs::GetModelState>("/gazebo/get_model_state");
    model.model_name = "igor";

    pub_general_state.data.resize(7);
    pub_states.data.resize(7);

    odom_baseLink = ros::Time::now();
    map_odom = ros::Time::now();

} // End of constructor

void igor_states_no_sensor::combineCallback(const sensor_msgs::Imu::ConstPtr &msg1, 
        const sensor_msgs::Imu::ConstPtr &msg2, const sensor_msgs::Imu::ConstPtr &msg3,
        const sensor_msgs::JointState::ConstPtr &msg4, const geometry_msgs::PointStamped::ConstPtr &msg5){
    
    get_state_service.call(model, objstate);
    robot_x = objstate.pose.position.x;
    robot_y = objstate.pose.position.y;
    
    igor_orient = objstate.pose.orientation;
    tf::quaternionMsgToTF(igor_orient, quat); // the incoming geometry_msgs::Quaternion is transformed to a tf::Quaternion
    quat.normalize(); // normalize the quaternion in case it is not normalized
    //the tf::Quaternion has a method to acess roll pitch and yaw
    tf::Matrix3x3(quat).getRPY(roll, pitch, yaw);
    igor_state(0) = robot_x * cos(yaw) + robot_y * sin(yaw);
    igor_state(1) = yaw;

    //msg1: body_imu_sub_
    //msg2: L_wheel_imu_sub_
    //msg3: R_wheel_imu_sub_
    //msg4: joint_states_sub_
    //msg5: CoG_sub_

    //msg1
    
    igor_angul_vel = msg1->angular_velocity;
    pitch_vel_y = floorf(igor_angul_vel.y*10000)/10000; // round off data upto 4 decimal points
    yaw_vel_z = floorf(igor_angul_vel.z*10000)/10000; 
   
    pitchVelVector.push_back(pitch_vel_y);
    igor_state(5) = pitch_vel_filt.filter(pitchVelVector);
    yawVelVector.push_back(yaw_vel_z);
    igor_state(4) = yaw_vel_filt.filter(yawVelVector);
    // ROS_INFO("angular velocity: %f",igor_state(4));

 
    //msg2 and msg3
    igor_angul_vel = msg2->angular_velocity;
    pitch_vel_y = floorf(igor_angul_vel.y*10000)/10000; // round off data upto 4 decimal points
    LWheelpitchVelVector.push_back(pitch_vel_y);    
    L_wheel_pitch_angul = L_wheel_pitch_vel_filt.filter(LWheelpitchVelVector);

    igor_angul_vel = msg3->angular_velocity;
    pitch_vel_y = floorf(igor_angul_vel.y*10000)/10000; // round off data upto 4 decimal points
    RWheelpitchVelVector.push_back(pitch_vel_y);    
    R_wheel_pitch_angul = R_wheel_pitch_vel_filt.filter(RWheelpitchVelVector);

    igor_state(3) = r_wheel * (L_wheel_pitch_angul + R_wheel_pitch_angul) / 2.0;
    // ROS_INFO("linear velocity: %f",igor_state(3));

    // broadcast the transform from odom to robot
    // sensor_time_current = ros::Time::now().toSec();
    // double delta_time = sensor_time_current - sensor_time_last;
    // wheel_odom_x = wheel_odom_x + igor_state(3) * delta_time * cos(wheel_odom_yaw);
    // wheel_odom_y = wheel_odom_y + igor_state(3) * delta_time * sin(wheel_odom_yaw);
    // wheel_odom_yaw = wheel_odom_yaw + igor_state(4) * delta_time;
    // odom_orientation_x = 0;
    // odom_orientation_y = 0;
    // odom_orientation_z = sin(wheel_odom_yaw/2);
    // odom_orientation_w = cos(wheel_odom_yaw/2);
    // sensor_time_last = sensor_time_current;
    // transform_.header.stamp = msg2->header.stamp;
    // transform_.header.frame_id = "odom";
    // transform_.child_frame_id = "base_link";
    // transform_.transform.translation.x = wheel_odom_x;
    // transform_.transform.translation.y = wheel_odom_y;
    // transform_.transform.translation.z = 0;
    // transform_.transform.rotation.x = odom_orientation_x;
    // transform_.transform.rotation.y = odom_orientation_y;
    // transform_.transform.rotation.z = odom_orientation_z;
    // transform_.transform.rotation.w = odom_orientation_w;
    // br.sendTransform(transform_);

    sensor_time_current = ros::Time::now().toSec();
    map_odom = ros::Time::now();
    transform2.header.stamp = map_odom;
    
    transform2.header.frame_id = "map";
    transform2.child_frame_id = "odom";
    transform2.transform.translation.x = 0;
    transform2.transform.translation.y = 0;
    transform2.transform.translation.z = 0;
    transform2.transform.rotation.x = 0;
    transform2.transform.rotation.y = 0;
    transform2.transform.rotation.z = 0;
    transform2.transform.rotation.w = 1;
    br2.sendTransform(transform2);

    if (sensor_time_current - sensor_time_last >= 0.01){
        sensor_time_last = sensor_time_current;
        transform1.header.stamp = odom_baseLink;
        odom_baseLink = map_odom;
        wheel_odom_yaw = yaw;
        odom_orientation_x = 0;
        odom_orientation_y = 0;
        odom_orientation_z = sin(wheel_odom_yaw/2);
        odom_orientation_w = cos(wheel_odom_yaw/2);
        
        transform1.header.frame_id = "odom";
        transform1.child_frame_id = "base_link";
        transform1.transform.translation.x = robot_x;
        transform1.transform.translation.y = robot_y;
        transform1.transform.translation.z = 0;
        transform1.transform.rotation.x = odom_orientation_x;
        transform1.transform.rotation.y = odom_orientation_y;
        transform1.transform.rotation.z = odom_orientation_z;
        transform1.transform.rotation.w = odom_orientation_w;
        br1.sendTransform(transform1);
    }

    
    
    
    
    

    //msg4

    //msg5
    CoG_Position = msg5->point;
    CoM_vec << CoG_Position.x, CoG_Position.y, CoG_Position.z;
    pitchRotation.setRPY(0,pitch,0); // Setting Pitch rotation matrix
    tf::matrixTFToEigen(pitchRotation, pitchRotEigen); // Converting tf matrix to Eigen matrix
    try
    { 
        leftLegTransformStamped = leftLegTfBuffer.lookupTransform("base_link", "L_wheelActuator" , ros::Time(0));
        rightLegTransformStamped = rightLegTfBuffer.lookupTransform("base_link", "R_wheelActuator" , ros::Time(0));
    }
    catch (tf2::TransformException &ex) 
    {
        ROS_WARN("%s",ex.what());
    }

    leftLegTranslation << leftLegTransformStamped.transform.translation.x, leftLegTransformStamped.transform.translation.y, leftLegTransformStamped.transform.translation.z;
    rightLegTranslation << rightLegTransformStamped.transform.translation.x, rightLegTransformStamped.transform.translation.y, rightLegTransformStamped.transform.translation.z;
    // Find the mean of the two legs' translation vectors in base_link frame
    groundPoint = 0.5*(leftLegTranslation+rightLegTranslation);
    //Get the vector starting from the "ground point" and ending at the position of the current center of mass
    CoM_line = CoM_vec - groundPoint;
    // Rotate it according to the current pitch angle of Igor
    CoM_line = pitchRotEigen * CoM_line; 
    CoM_height =  CoM_line.norm();
    // Lean/Pitch angle of CoM from the wheel base 
    leanAngle = atan2(CoM_line.x(), CoM_line.z());
    my_data1.push_back(leanAngle);
    CoG_angle_filtered = f1.filter(my_data1);
    igor_state(2) = CoG_angle_filtered;   

    pub_general_state.data[0] = robot_x;
    pub_general_state.data[1] = robot_y;
    pub_general_state.data[2] = igor_state(1);
    pub_general_state.data[3] = igor_state(3);
    pub_general_state.data[4] = igor_state(4);
    pub_general_state.data[5] = igor_state(2);
    pub_general_state.data[6] = igor_state(5);
    igor_general_state_publisher.publish(pub_general_state);

    for (int ii = 0; ii < 6; ii++){
        pub_states.data[ii] = igor_state(ii);
    }
    pub_states.data[6] = CoM_height;
    igor_state_publisher.publish(pub_states);
}


igor_states_no_sensor::~igor_states_no_sensor()
{

} // End of destructor


int main(int argc, char **argv){
    ros::init(argc, argv, "igor_states_no_sensor"); // node name, can be superseded by node name in the launch file
    ros::NodeHandle nh;
    igor_states_no_sensor myNode(&nh); // creating the igor_knee_control object
    ros::MultiThreadedSpinner spinner(1); // Use 5 threads for 5 callbacks in parallel
    spinner.spin(); // spin() will not return until the node has been shutdown
    return 0;

} // end of main