#include <ros/ros.h>
#include <tf2_ros/transform_listener.h>
#include <tf/transform_listener.h>
#include <tf2_ros/buffer.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <geometry_msgs/TransformStamped.h>
#include "std_msgs/Float64.h"
#include <std_msgs/Float32MultiArray.h>
#include <math.h>
#include "tf/transform_datatypes.h"
#include "nav_msgs/Odometry.h"

std_msgs::Float32MultiArray states;

geometry_msgs::TransformStamped MapBaseLinkTransformStamped;
tf2_ros::Buffer MapBaseLinkTfBuffer;


void odom_callback(const nav_msgs::Odometry::ConstPtr &msg)
{
  try
    { 
        MapBaseLinkTransformStamped = MapBaseLinkTfBuffer.lookupTransform("map", "base_link" , ros::Time(0));
    }
    catch (tf2::TransformException &ex) 
    {
        ROS_WARN("%s",ex.what());
        ros::Duration(1.0).sleep();
    }
    states.data[0] = MapBaseLinkTransformStamped.transform.translation.x;
    states.data[1] = MapBaseLinkTransformStamped.transform.translation.y;
    states.data[2] = tf::getYaw(MapBaseLinkTransformStamped.transform.rotation);
    states.data[3] = msg->twist.twist.linear.x 
    states.data[4] = msg->twist.twist.angular.z 
    
}

int main(int argc, char** argv){
  ros::init(argc, argv, "my_tf_listener");
  ros::NodeHandle node;
  sub_odom = node.subscribe<nav_msgs::Odometry>("/odometry/filtered",5, odom_callback,ros::TransportHints().tcpNoDelay());
  ros::Publisher  states_publisher = node.advertise<std_msgs::Float32MultiArray>( "/igor/states", 5);
  states.data.resize(6);
  tf2_ros::TransformListener MapBaseLinkTfListener{MapBaseLinkTfBuffer};
  ros::Rate rate(50.0);

  while (node.ok()){
    states_publisher.publish(states);
    ros::spinOnce();
    rate.sleep();
  }
  return 0;
}