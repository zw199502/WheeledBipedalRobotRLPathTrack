#include "dwa_planner.h"

#define M_PI 3.14159265358979323846

float x=0, y=0, v_linear=0, v_angular=0;

double roll=0, pitch=0, yaw=0;
double HZ = 20;

void state_callback(const gazebo_msgs::ModelStates &msg){
    geometry_msgs::Twist vel_com;
    tf::Quaternion quat;
    geometry_msgs::Quaternion  model_orient;
    
    model_orient = msg.pose[6].orientation;
    tf::quaternionMsgToTF(model_orient, quat);
    quat.normalize();
    tf::Matrix3x3(quat).getRPY(roll, pitch, yaw);

    x = msg.pose[6].position.x;
    y = msg.pose[6].position.y;
    v_linear = msg.twist[6].linear.x;
    v_angular = msg.twist[6].angular.z;
    
    
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "dwa_planner");
    DWAPlanner planner;
    ros::NodeHandle nh;
    // need to change, subscribe the state of igor
    ros::Subscriber sub_state = nh.subscribe("/gazebo/model_states",1, state_callback);
    ros::Publisher  pub_v;
    // need to change, publish linear and angular velocities to igor
    pub_v = nh.advertise<geometry_msgs::Twist>( "/mobile_base/commands/velocity", 1 );
    geometry_msgs::Twist vel_com;
    ros::Rate loop_rate(500);

    float dx = 0.0, dy = 0.0, dr = 0.0;
    Eigen::Vector3d goal(0.2, 0.2, 0.0);
    std::vector<std::vector<float> > obs_list; // positions of obstacles
    std::vector<float> obs_state = {0.1, 0};
    obs_list.push_back(obs_state);
    obs_state[0] = 0.2; 
    obs_state[1] = 0.15;
    obs_list.push_back(obs_state); 
    std::vector<std::vector<float> > goal_list; // positions of subsequent goals
    std::vector<float> goal_state = {0.0, 0.0};
    for(float i = 10.0; i >= 0.0; i-=0.05){
        goal_state[0] = i;
        goal_state[1] = 0.25 * sin(2 * M_PI * i);
        goal_list.push_back(goal_state);
    }
    
    int count_target_position = 0;
    int count_planner = 0;
    
    while((ros::ok())&&(!goal_list.empty())){
        goal(0) = (goal_list.back())[0];
        goal(1) = (goal_list.back())[1];
        
        // dx = goal(0) - x;
        // dy = goal(1) - y;
        // dr = sqrt(dx * dx + dy * dy);
        // if (dr < 0.015){ // when approaching current goal
        if (count_target_position == 250){ 
            goal_list.pop_back();
            std::cout<<"current goal"<<std::endl;
            std::cout<<goal(0)<<std::endl;
            std::cout<<goal(1)<<std::endl;
            count_target_position = 0;
        }
        if (count_planner == 25){
            planner.pose_x = x;
            planner.pose_y = y;
            planner.pose_yaw = yaw;
            planner.v_linear = v_linear;
            planner.v_angular = v_angular;
            std::cout<<"current pose"<<std::endl;
            std::cout<<planner.pose_x<<std::endl;
            std::cout<<planner.pose_y<<std::endl;
            std::cout<<planner.pose_yaw<<std::endl;
            // std::cout<<planner.v_linear<<std::endl;
            // std::cout<<planner.v_angular<<std::endl;
            // std::cout<<"ok"<<std::endl;
            planner.process(goal, obs_list);
            count_planner = 0;
        }
        
        vel_com.linear.x = planner.target_state[3];
        // vel_com.linear.x = 0.1;
        vel_com.angular.z = planner.target_state[4];
        pub_v.publish(vel_com);
        // std::cout<<planner.target_state[3]<<std::endl;
        // std::cout<<planner.target_state[4]<<std::endl;

        count_target_position++;
        count_planner++;
        ros::spinOnce();
        loop_rate.sleep();
    }

    return 0;
}
