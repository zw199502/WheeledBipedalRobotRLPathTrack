#include "igor_pid_control.h"


pthread_mutex_t mutex1 ;

igor_pid_control::igor_pid_control(ros::NodeHandle* nodehandle):nh_(*nodehandle) //Constructor
{
    body_imu_sub_  = new message_filters::Subscriber<sensor_msgs::Imu>(nh_, "/igor/body_imu/data", 1);
    joint_states_sub_ = new message_filters::Subscriber<sensor_msgs::JointState>(nh_, "/igor/joint_states", 1);
    CoG_sub_ = new message_filters::Subscriber<geometry_msgs::PointStamped>(nh_, "/cog/robot", 1);
    sync_ = new  message_filters::Synchronizer<SyncPolicy>(SyncPolicy(10), *body_imu_sub_,
        *joint_states_sub_, *CoG_sub_);
    sync_->registerCallback(boost::bind(&igor_pid_control::combineCallback,this,_1,_2,_3));

    sub_command_velocity = nh_.subscribe<geometry_msgs::Twist>("/igor/commands/velocity",1, 
                            &igor_pid_control::command_velocity_callback,this);

    Lwheel_pub = nh_.advertise<std_msgs::Float64>( "/igor/L_wheel_joint_effort_controller/command", 1 );
    Rwheel_pub = nh_.advertise<std_msgs::Float64>( "/igor/R_wheel_joint_effort_controller/command", 1 );
    Lknee_pub = nh_.advertise<std_msgs::Float64>( "/igor/L_kfe_joint_position_controller/command", 1 );
    Rknee_pub = nh_.advertise<std_msgs::Float64>( "/igor/R_kfe_joint_position_controller/command", 1 );
    Lhip_pub = nh_.advertise<std_msgs::Float64>( "/igor/L_hfe_joint_position_controller/command", 1 );
    Rhip_pub = nh_.advertise<std_msgs::Float64>( "/igor/R_hfe_joint_position_controller/command", 1 );

    position_Lhip.data = 0.325;
    position_Rhip.data = -0.325;
    position_Lknee.data = 0.65;
    position_Rknee.data = -0.65;
    tqr_Lwheel.data = 0;
    tqr_Rwheel.data = 0;
}

void igor_pid_control::command_velocity_callback(const geometry_msgs::Twist::ConstPtr &msg){
    command_linear_velocity = msg->linear.x;
    command_angular_velocity = msg->angular.z;
    leanD = msg->linear.y;
    velD = msg->linear.z;
}

void igor_pid_control::combineCallback(const sensor_msgs::Imu::ConstPtr &msg1, 
                         const sensor_msgs::JointState::ConstPtr &msg2, 
                         const geometry_msgs::PointStamped::ConstPtr &msg3)
{
    pthread_mutex_lock(&mutex1);

    //msg1: body_imu_sub_
    //msg2: joint_states_sub_
    //msg3: CoG_sub_

    //msg1
    igor_orient = msg1->orientation; // a geometery_msg quaternion
    leanAngle_dot = floorf(msg1->angular_velocity.y*10000)/10000; // round off data upto 4 decimal points
    tf::quaternionMsgToTF(igor_orient, quat); // the incoming geometry_msgs::Quaternion is transformed to a tf::Quaternion
    quat.normalize(); // normalize the quaternion in case it is not normalized
    //the tf::Quaternion has a method to acess roll pitch and yaw
    tf::Matrix3x3(quat).getRPY(roll, pitch, yaw);

    //msg2
    L_wheel_angular_vel = msg2->velocity[2];
    R_wheel_angular_vel = msg2->velocity[5];
    current_linear_vel = r_wheel * (L_wheel_angular_vel - R_wheel_angular_vel) / 2.0;
    current_angular_vel = -r_wheel * (L_wheel_angular_vel + R_wheel_angular_vel) / l_wheel;
    current_Lhip_position = msg2->position[1];
    current_Rhip_position = msg2->position[4];
    current_Lknee_position = msg2->position[0];
    current_Rknee_position = msg2->position[3];

    //msg3
    CoG_Position = msg3->point;
    CoM_vec << CoG_Position.x, CoG_Position.y, CoG_Position.z;
    // std::cout<<"CoM_vec:  "<<CoM_vec.x()<<"  "<<CoM_vec.y()<<"  "<<CoM_vec.z()<<std::endl;
    // CoM_vec << 0.023, 0.0, -0.025;
    pitchRotation.setRPY(0,pitch,0); // Setting Pitch rotation matrix
    tf::matrixTFToEigen(pitchRotation, pitchRotEigen); // Converting tf matrix to Eigen matrix
    try
    { 
        leftLegTransformStamped = leftLegTfBuffer.lookupTransform("base_link", "left_wheel_body" , ros::Time(0));
        rightLegTransformStamped = rightLegTfBuffer.lookupTransform("base_link", "right_wheel_body" , ros::Time(0));
    }
    catch (tf2::TransformException &ex) 
    {
        ROS_WARN("%s",ex.what());
    }

    leftLegTranslation << leftLegTransformStamped.transform.translation.x, leftLegTransformStamped.transform.translation.y, leftLegTransformStamped.transform.translation.z;
    rightLegTranslation << rightLegTransformStamped.transform.translation.x, rightLegTransformStamped.transform.translation.y, rightLegTransformStamped.transform.translation.z;
    // Find the mean of the two legs' translation vectors in base_link frame
    groundPoint = 0.5*(leftLegTranslation+rightLegTranslation);
    // relative to hip actuator
    // groundPoint.z() = groundPoint.z() - r_wheel;
    // groundPoint.x() = groundPoint.x() - 0.01;
    // std::cout<<"groundPoint: "<<groundPoint.x()<<"  "<<groundPoint.z()<<std::endl;
    //Get the vector starting from the "ground point" and ending at the position of the current center of mass
    CoM_line = CoM_vec - groundPoint;
    
    // Rotate it according to the current pitch angle of Igor
    CoM_line = pitchRotEigen * CoM_line; 
    // CoM_line: -0.00179976  0.642385
    // std::cout<<"CoM_line: "<<CoM_line.x()<<"  "<<CoM_line.z()<<std::endl;
    CoM_height =  CoM_line.norm();
    // Lean/Pitch angle of CoM from the wheel base 
    
    leanAngle = atan2(CoM_line.x(), CoM_line.z());
    // std::cout<<"CoM_line:   "<<CoM_line.x()<<"  "<<CoM_line.z()<<std::endl;
    // std::cout<<"groundPoint:   "<<groundPoint[0]<<"  "<<groundPoint[1]<<"  "<<groundPoint[2]<<std::endl;
    
    pthread_mutex_unlock(&mutex1);
}

void igor_pid_control::pidController(void){
    pthread_mutex_lock(&mutex1);

    if(abs(leanAngle) > (30.0/180.0*M_PI)){
        tqr_Lwheel.data = 0;
        tqr_Rwheel.data = 0;
        Lwheel_pub.publish(tqr_Lwheel);
        Rwheel_pub.publish(tqr_Rwheel);
        return;
    }

    linear_vel_feedforward = command_linear_velocity / r_wheel;
    angular_vel_feedforward = -command_angular_velocity * l_wheel / r_wheel / 2.0;

    command_linear_accel = (command_linear_velocity - command_linear_velocity_last) * HZ;
    command_linear_velocity_last = command_linear_velocity;
    
    lean_feedforward = 0.1*robot_mass*command_linear_accel/CoM_height;

    current_coupled_linear_vel = current_linear_vel + CoM_height * leanAngle_dot;
    error_linear_vel = command_linear_velocity - current_coupled_linear_vel;
    // std::cout<<"current_linear_vel: "<<current_linear_vel<<std::endl;
    error_linear_vel_cumulative +=  error_linear_vel * dt;
    if (error_linear_vel_cumulative > 30.0){
        error_linear_vel_cumulative = 30;
    }
    else{
        if (error_linear_vel_cumulative < -30.0){
            error_linear_vel_cumulative = -30;
        }
    }
    // linear_accel = (current_coupled_linear_vel - last_coupled_linear_vel) * HZ;
    // last_coupled_linear_vel = current_coupled_linear_vel;

    // command_lean_angle = (velP * error_linear_vel) + (velI * error_linear_vel_cumulative) + (
    //       velD * linear_accel) + lean_feedforward;

    error_linear_vel_differential = (error_linear_vel - error_linear_vel_last) * HZ;
    error_linear_vel_last = error_linear_vel;

    command_lean_angle = (velP * error_linear_vel) + (velI * error_linear_vel_cumulative) + (
          velD * error_linear_vel_differential) + lean_feedforward;

    if (abs(leanAngle)<=(10.0/180.0*M_PI)){
        // std::cout<<"L_wheel_angular_vel: "<<L_wheel_angular_vel<<std::endl;
        // std::cout<<"R_wheel_angular_vel: "<<R_wheel_angular_vel<<std::endl;
        // std::cout<<"current_coupled_linear_vel: "<<current_coupled_linear_vel<<std::endl;
    }
    
    
    // error_lean_angle = -command_lean_angle + leanAngle;
    error_lean_angle = command_lean_angle - leanAngle;
    error_lean_angle_cumulative += error_lean_angle * dt;
    error_lean_angle_differential = (error_lean_angle - error_lean_angle_last) * HZ;
    error_lean_angle_last = error_lean_angle;
   
    // if (error_lean_angle_cumulative > 0.2/180.0*M_PI){
    //     error_lean_angle_cumulative = 0.2/180.0*M_PI;
    // }
   
    // if (error_lean_angle_cumulative < -0.2/180.0*M_PI){
    //     error_lean_angle_cumulative = -0.2/180.0*M_PI;
        
    // }

    if (error_lean_angle_cumulative > 0.3){
        error_lean_angle_cumulative = 0.3;
    }
   
    if (error_lean_angle_cumulative < -0.3){
        error_lean_angle_cumulative = -0.3;
    }

    // effort_balance = (leanP*error_lean_angle)+(leanI*error_lean_angle_cumulative) + (leanD*leanAngle_dot);
    effort_balance = (leanP*error_lean_angle)+(leanI*error_lean_angle_cumulative) + (leanD*error_lean_angle_differential);
    if (abs(leanAngle)<=(10.0/180.0*M_PI)){
        lean_count ++;
        // std::cout<<"CoM_line: "<<CoM_line.x()<<"   "<<CoM_line.z()<<std::endl;
        // std::cout<<"R_wheel_angular_vel: "<<R_wheel_angular_vel<<std::endl;
        // std::cout<<"CoM_line.x(): "<<CoM_line.x()<<std::endl;
        // std::cout<<"CoM_line.z(): "<<CoM_line.z()<<std::endl;
        // std::cout<<"effort_balance: "<<effort_balance<<std::endl;
    }
   
    if (abs(leanAngle)>(25.0/180.0*M_PI)){
        std::cout<<"lean_count: "<<lean_count<<std::endl;
    }
    // std::cout<<"command_lean_angle: "<<command_lean_angle<<"  leanAngle: "<<leanAngle<<"  effort: "<<effort_balance<<std::endl;
    
    if(effort_balance > 3.5){
        effort_balance = 3.5;
    }
    if(effort_balance < -3.5){
        effort_balance = -3.5;
    }
    // std::cout<<"leanAngle: "<<leanAngle<<std::endl;
    // std::cout<<"pitch: "<<pitch<<std::endl;
    // std::cout<<"error: "<<(leanAngle - pitch)<<std::endl;
    // std::cout<<"effort_balance: "<<effort_balance<<std::endl;
    // std::cout<<"CoM_height: "<<CoM_height<<std::endl;

    // command_vel_Lwheel = angular_vel_feedforward + linear_vel_feedforward;
    // command_vel_Rwheel = angular_vel_feedforward - linear_vel_feedforward;
    command_vel_Lwheel = angular_vel_feedforward;
    command_vel_Rwheel = angular_vel_feedforward;

    error_vel_Lwheel = command_vel_Lwheel - L_wheel_angular_vel;
    error_vel_Lwheel_accumlative += error_vel_Lwheel * dt;
    if (error_vel_Lwheel_accumlative > 30.0){
        error_vel_Lwheel_accumlative = 30;
    }
    else{
        if (error_vel_Lwheel_accumlative < -30.0){
            error_vel_Lwheel_accumlative = -30;
        }
    }

    error_vel_Rwheel = command_vel_Rwheel - R_wheel_angular_vel;
    error_vel_Rwheel_accumlative += error_vel_Rwheel * dt;
    if (error_vel_Rwheel_accumlative > 30.0){
        error_vel_Rwheel_accumlative = 30;
    }
    else{
        if (error_vel_Rwheel_accumlative < -30.0){
            error_vel_Rwheel_accumlative = -30;
        }
    }

    effort_vel_Lwheel = (wheelRotationP*error_vel_Lwheel)+(wheelRotationI*error_vel_Lwheel_accumlative);
    effort_vel_Rwheel = (wheelRotationP*error_vel_Rwheel)+(wheelRotationI*error_vel_Rwheel_accumlative);        

    tqr_Lwheel.data = effort_balance;
    tqr_Rwheel.data = -effort_balance;
    // tqr_Lwheel.data = effort_balance + effort_vel_Lwheel;
    // tqr_Rwheel.data = -effort_balance + effort_vel_Rwheel;

    Lwheel_pub.publish(tqr_Lwheel);
    Rwheel_pub.publish(tqr_Rwheel);

    Lknee_pub.publish(position_Lknee);
    Rknee_pub.publish(position_Rknee);
    Lhip_pub.publish(position_Lhip);
    Rhip_pub.publish(position_Rhip);
    count ++;
    
    if (count == 5){
        // std::cout<<"pitch: "<<pitch<<"  "<<"leanAngle: "<<leanAngle<<std::endl;
        // std::cout<<"command_lean_angle: "<<command_lean_angle<<std::endl;
        count = 0;
    }
    pthread_mutex_unlock(&mutex1);
}

igor_pid_control::~igor_pid_control()
{

} // End of destructor


int main(int argc, char **argv){
    ros::init(argc, argv, "igor_controller"); // node name, can be superseded by node name in the launch file
    ros::NodeHandle nh;
    igor_pid_control myNode(&nh); // creating the igor_knee_control object
    ros::Rate loop_rate(myNode.HZ);
    pthread_mutex_init(&mutex1,NULL);// initialize a mutually exclusive lock
    // ros::Duration(0.3).sleep();
    while(ros::ok()){
        myNode.pidController();
        ros::spinOnce();
        loop_rate.sleep();
    }
    pthread_mutex_destroy(&mutex1);
    return 0;
} // end of main
