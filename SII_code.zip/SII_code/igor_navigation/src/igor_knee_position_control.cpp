#include "igor_knee_control.h"

/***  This node is used to control Igor in Gazebo simulator. It has three controllers 1. LQR, 2. Computed Troque controller, 3. Feedforward+feedback controller.
 *    Call one controller at a time.
 * 
 *    ***/



igor_knee_control::igor_knee_control(ros::NodeHandle* nodehandle):nh_(*nodehandle) //Constructor
{
    sub_command_velocity = nh_.subscribe<geometry_msgs::Twist>("/igor/commands/velocity",1, &igor_knee_control::command_velocity_callback,this);
    clk_subscriber = nh_.subscribe<rosgraph_msgs::Clock>("/clock",10,&igor_knee_control::clk_callback,this);
    sub_states = nh_.subscribe("/igor/igor_actual_state", 10, &igor_knee_control::statesCallback,this);
    
    Lwheel_pub = nh_.advertise<std_msgs::Float64>( "/igor/L_wheel_joint_effort_controller/command", 1 );
    Rwheel_pub = nh_.advertise<std_msgs::Float64>( "/igor/R_wheel_joint_effort_controller/command", 1 );
    Lknee_pub = nh_.advertise<std_msgs::Float64>( "/igor/L_kfe_joint_position_controller/command", 1 );
    Rknee_pub = nh_.advertise<std_msgs::Float64>( "/igor/R_kfe_joint_position_controller/command", 1 );
    Lhip_pub = nh_.advertise<std_msgs::Float64>( "/igor/L_hfe_joint_position_controller/command", 1 );
    Rhip_pub = nh_.advertise<std_msgs::Float64>( "/igor/R_hfe_joint_position_controller/command", 1 );

    client = nh_.serviceClient<std_srvs::Empty>("/gazebo/reset_world"); // service client of gazebo service

    // LQR gains
    k_r(0,0)= k_l(0,0) = 4*(-0.7071); // Forward position gain -ve
    k_r(0,1)= 2*(0.7071); // Yaw gain +ve
    k_r(0,2)= k_l(0,2) = 1.2*(-16.2331); // Pitch gain -ve
    k_r(0,3)= k_l(0,3) = (-4.8849); // Forward speed gain -ve
    k_r(0,4)= (0.4032); // Yaw speed gain +ve
    k_r(0,5)= k_l(0,5)= 1.5*(-3.1893); // Pitch speed gain -ve
    k_l(0,1)= -1*k_r(0,1);
    k_l(0,4)= -1*k_r(0,4);

    // Reference states
    ref_state(0) = 0; // Center Position 
    ref_state(1) = 0; // Yaw
    ref_state(2) = 0.0; // Beta
    ref_state(3) = 0; // Center velocity
    ref_state(4) = 0; // yaw velocity
    ref_state(5) = 0.0; // Pitch velocity

    knee_ref.data = -0.65;
    hip_ref.data = 0.329;
    dwa_linear_velocity = 0;
    dwa_angular_velocity = 0;

} // End of constructor

void igor_knee_control::command_velocity_callback(const geometry_msgs::Twist::ConstPtr &msg){
    dwa_linear_velocity = msg->linear.x;
    dwa_angular_velocity = msg->angular.z;
}

void igor_knee_control::statesCallback(const std_msgs::Float32MultiArray::ConstPtr &msg)
{   
    for (int ii = 0; ii < 6; ii++){
        igor_state(ii) = msg->data.at(ii);
    }
    CoM_height = msg->data.at(6);
    this->ref_update();
    this->lqr_controller(igor_state);
}// End of imu_callback

void igor_knee_control::clk_callback(const rosgraph_msgs::Clock::ConstPtr &msg){

    sim_time = msg->clock;

} // End of clk_callback


void igor_knee_control::lqr_controller (Eigen::VectorXf vec) //LQR State-feedback controller
{
    // ROS_INFO("In LQR");
    if (igor_state(2)>= -0.35 && igor_state(2) <= 0.35){
        
        // rightTrqVector.push_back((k_r*(vec-ref_state)).value());
        // trq_r.data = trq_r_filt.filter(rightTrqVector);
        
        lqr_right_trq = lqr_trq_r.data =  (k_r*(ref_state-vec)).value(); // taking the scalar value of the eigen-matrx
      
        // leftTrqVector.push_back((k_l*(vec-ref_state)).value());
        // trq_l.data = trq_l_filt.filter(leftTrqVector); 
        lqr_left_trq = lqr_trq_l.data =  (k_l*(ref_state-vec)).value();

        Lwheel_pub.publish(lqr_trq_l); // Publish left wheel torque
        Rwheel_pub.publish(lqr_trq_r); // Publish right wheel torque
       
    }
    else if (igor_state(2)<= -1.4 || igor_state(2) >= 1.4){
        lqr_right_trq = lqr_trq_r.data = 0;
        lqr_left_trq = lqr_trq_l.data = 0;
        Lwheel_pub.publish(lqr_trq_l);
        Rwheel_pub.publish(lqr_trq_r);
        
        ROS_INFO("Reseting Model");
        ros::Duration(0.5).sleep(); // sleep for half a second
        client.call(srv); // Calling the service to reset robot model in gazebo
    }
    
} // End of lqr_controller

void igor_knee_control::ref_update()
{
    // ROS_INFO("In ref_update");    
    ref_state(1) = ref_state(1) + dwa_angular_velocity * 0.002;
    // ref_state(4) = dwa_angular_velocity;
    // ref_state(1) = 0.5;
    ref_state(0) = ref_state(0) + dwa_linear_velocity * 0.002;
    ref_state(3) = dwa_linear_velocity;
    
}// End of ref_update function

igor_knee_control::~igor_knee_control()
{

} // End of destructor


int main(int argc, char **argv){
ros::init(argc, argv, "igor_controller"); // node name, can be superseded by node name in the launch file
ros::NodeHandle nh;
igor_knee_control myNode(&nh); // creating the igor_knee_control object
ros::Duration(0.1).sleep();
ros::MultiThreadedSpinner spinner(3); // Use 5 threads for 5 callbacks in parallel
spinner.spin(); // spin() will not return until the node has been shutdown
return 0;

} // end of main
