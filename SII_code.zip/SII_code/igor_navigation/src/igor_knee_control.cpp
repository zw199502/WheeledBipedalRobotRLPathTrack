#include "igor_knee_control.h"

/***  This node is used to control Igor in Gazebo simulator. It has three controllers 1. LQR, 2. Computed Troque controller, 3. Feedforward+feedback controller.
 *    Call one controller at a time.
 * 
 *    ***/



igor_knee_control::igor_knee_control(ros::NodeHandle* nodehandle):nh_(*nodehandle) //Constructor
{
   
    sub_command_velocity = nh_.subscribe<geometry_msgs::Twist>("/igor/commands/velocity",1, &igor_knee_control::command_velocity_callback,this);
    clk_subscriber = nh_.subscribe<rosgraph_msgs::Clock>("/clock",10,&igor_knee_control::clk_callback,this);
    sub_states = nh_.subscribe("/igor/igor_actual_state", 10, &igor_knee_control::statesCallback,this);
    
    Lwheel_pub = nh_.advertise<std_msgs::Float64>( "/igor/L_wheel_joint_effort_controller/command", 1 );
    Rwheel_pub = nh_.advertise<std_msgs::Float64>( "/igor/R_wheel_joint_effort_controller/command", 1 );
    Lknee_pub = nh_.advertise<std_msgs::Float64>( "/igor/L_kfe_joint_position_controller/command", 1 );
    Rknee_pub = nh_.advertise<std_msgs::Float64>( "/igor/R_kfe_joint_position_controller/command", 1 );
    Lhip_pub = nh_.advertise<std_msgs::Float64>( "/igor/L_hfe_joint_position_controller/command", 1 );
    Rhip_pub = nh_.advertise<std_msgs::Float64>( "/igor/R_hfe_joint_position_controller/command", 1 );

    client = nh_.serviceClient<std_srvs::Empty>("/gazebo/reset_world"); // service client of gazebo service

    // LQR gains
    // k_r(0,0)= k_l(0,0) = 4*(-0.7071); // Forward position gain -ve
    // k_r(0,1)= 2*(0.7071); // Yaw gain +ve
    // k_r(0,2)= k_l(0,2) = 1.2*(-16.2331); // Pitch gain -ve
    // k_r(0,3)= k_l(0,3) = (-4.8849); // Forward speed gain -ve
    // k_r(0,4)= (0.4032); // Yaw speed gain +ve
    // k_r(0,5)= k_l(0,5)= 1.5*(-3.1893); // Pitch speed gain -ve
    // k_l(0,1)= -1*k_r(0,1);
    // k_l(0,4)= -1*k_r(0,4);

    k_r(0,0)= k_l(0,0) = 0; // Forward position gain -ve
    k_r(0,1)= 0; // Yaw gain +ve
    k_r(0,2)= k_l(0,2) = 1.2*(-16.2331); // Pitch gain -ve
    k_r(0,3)= k_l(0,3) = (-4.8849); // Forward speed gain -ve
    k_r(0,4)= (0.4032); // Yaw speed gain +ve
    k_r(0,5)= k_l(0,5)= 1.5*(-3.1893); // Pitch speed gain -ve
    k_l(0,1)= 0;
    k_l(0,4)= -1*k_r(0,4);

    // LQR gains for ff_fb_controller
    // k_r(0,0)= k_l(0,0) = (-0.7071); // Forward position gain -ve
    // k_r(0,1)= (0.7071); // Yaw gain +ve
    // k_r(0,2)= k_l(0,2) = (-16.2331); // Pitch gain -ve
    // k_r(0,3)= k_l(0,3) = 0.65*(-4.8849); // Forward speed gain -ve
    // k_r(0,4)= 0.5*(0.4032); // Yaw speed gain +ve
    // k_r(0,5)= k_l(0,5)= 1.2*(-3.1893); // Pitch speed gain -ve
    // k_l(0,1)= -1*k_r(0,1);
    // k_l(0,4)= -1*k_r(0,4);



    // Viscous friction matrix
    V_h(0,0) = 48.4376;  
    V_h(0,1) = 0;
    V_h(0,2) = -4.9213;
    V_h(1,0) =  0; 
    V_h(1,1) =  2.2390;
    V_h(1,2) =  0;
    V_h(2,0) = -4.9213;
    V_h(2,1) =  0; 
    V_h(2,2) =  0.5000;


    // Torque selection matrix
    E_h_inv(0,0) = 0.0503;   
    E_h_inv(0,1) = 0.1605;  
    E_h_inv(0,2) = -0.0051;
    E_h_inv(1,0) = 0.0503;  
    E_h_inv(1,1) = -0.1605;  
    E_h_inv(1,2) = -0.0051;
   
    // Computed-torque controller's gain
    Kp(0,0) = Kp1;
    Kp(0,1) = 0;
    Kp(0,2) = 0;
    Kp(1,0) = 0;
    Kp(1,1) = Kp2;
    Kp(1,2) = 0;
    Kp(2,0) = 0;
    Kp(2,1) = 0;
    Kp(2,2) = Kp3;

    Kv(0,0) = Kv1;
    Kv(0,1) = 0;
    Kv(0,2) = 0;
    Kv(1,0) = 0;
    Kv(1,1) = Kv2;
    Kv(1,2) = 0;
    Kv(2,0) = 0;
    Kv(2,1) = 0;
    Kv(2,2) = Kv3;

    // Reference states
    ref_state(0) = 0; // Center Position 
    ref_state(1) = 0; // Yaw
    ref_state(2) = 0.0; // Beta
    ref_state(3) = 0; // Center velocity
    ref_state(4) = 0; // yaw velocity
    ref_state(5) = 0.0; // Pitch velocity

    knee_ref.data = -0.65;
    hip_ref.data = 0.329;

    for (int i = 0; i < 500; i++){
        igor_linear_vel(i) = 0.0;
        igor_angular_vel(i) = 0.0;
    }

} // End of constructor

void igor_knee_control::command_velocity_callback(const geometry_msgs::Twist::ConstPtr &msg){
    dwa_linear_velocity = msg->linear.x;
    dwa_angular_velocity = msg->angular.z;
    igor_knee_control::ref_update();
}

void igor_knee_control::statesCallback(const std_msgs::Float32MultiArray::ConstPtr &msg)
{
    mylock.lock();
    for (int ii = 0; ii < 6; ii++){
        igor_state(ii) = msg->data.at(ii);
    }
    // if (counts == 2500){
    //     ROS_INFO("linear vel: %f", igor_linear_vel.sum() / 500.0);
    //     ROS_INFO("angular vel: %f", igor_angular_vel.sum() / 500.0);
    //     counts = 0;
    // }
    // if (counts >= 2000){
    //     igor_linear_vel(counts - 2000) = igor_state(3);
    //     igor_angular_vel(counts - 2000) = igor_state(4);
    // }
    
    // counts ++;
    // ROS_INFO("linear vel: %f", igor_state(3));
    // ROS_INFO("angular vel: %f", igor_state(4));
    CoM_height = msg->data.at(6);
    this->CT_controller(igor_state); // simulation for iros
    // this->lqr_controller(igor_state);
    mylock.unlock();
}// End of imu_callback

void igor_knee_control::clk_callback(const rosgraph_msgs::Clock::ConstPtr &msg){

    sim_time = msg->clock;

} // End of clk_callback


void igor_knee_control::lqr_controller (Eigen::VectorXf vec) //LQR State-feedback controller
{
    // ROS_INFO("In LQR");
    if (igor_state(2)>= -0.35 && igor_state(2) <= 0.35){
        
        // rightTrqVector.push_back((k_r*(vec-ref_state)).value());
        // trq_r.data = trq_r_filt.filter(rightTrqVector);

        lqr_right_trq = lqr_trq_r.data =  (k_r*(ref_state-vec)).value(); // taking the scalar value of the eigen-matrx
      
        // leftTrqVector.push_back((k_l*(vec-ref_state)).value());
        // trq_l.data = trq_l_filt.filter(leftTrqVector); 
        lqr_left_trq = lqr_trq_l.data =  (k_l*(ref_state-vec)).value();
        

        Lwheel_pub.publish(lqr_trq_l); // Publish left wheel torque
        Rwheel_pub.publish(lqr_trq_r); // Publish right wheel torque
       
    }
    else if (igor_state(2)<= -1.4 || igor_state(2) >= 1.4){
        lqr_right_trq = lqr_trq_r.data = 0;
        lqr_left_trq = lqr_trq_l.data = 0;
        Lwheel_pub.publish(lqr_trq_l);
        Rwheel_pub.publish(lqr_trq_r);
        
        ROS_INFO("Reseting Model");
        ros::Duration(0.5).sleep(); // sleep for half a second
        client.call(srv); // Calling the service to reset robot model in gazebo
    }
    
} // End of lqr_controller

void igor_knee_control::CT_controller(Eigen::VectorXf vec) // Computed Torque controller
{
    // ROS_INFO("In CT control");

    float L = CoM_height; //0.5914; // CoM height

    velocities(0) = vec(3); // Center velocity
    velocities(1) = vec(4); // Yaw velocity
    velocities(2) = vec(5); // Pitch velocity

    // Inertia matrix
    M_h(0,0)= 8.55;
    M_h(0,1)= 0;
    M_h(0,2) = 7.5*L*cos(vec(2));
    M_h(1,0)= 0;
    M_h(1,1)= 7.5*pow(L,2) - pow(cos(vec(2)),2)*(7.5*pow(L,2) + 0.0246) + 0.1382;
    M_h(1,2)= 0;
    M_h(2,0) = 7.5*L*cos(vec(2));
    M_h(2,1)= 0;
    M_h(2,2)= 7.5*pow(L,2) + 0.0347;

   // Coriolis and centrifugal vector 
    H_h(0) = -7.5*L*sin(vec(2))*(pow(vec(4),2) + pow(vec(5),2));
    H_h(1) = 6.0000e-04*vec(4)*(12500*vec(5)*sin(2*vec(2))*pow(L,2) + 12500*vec(3)*sin(vec(2))*L + 41*vec(5)*sin(2*vec(2)));
    H_h(2) = -0.5000*pow(vec(4),2)*sin(2*vec(2))*(7.5000*pow(L,2) + 0.0246);

    // Gravity vector
    G_h(0) = 0;
    G_h(1) = 0;
    G_h(2) = -73.5750*L*sin(vec(2));

    // Position errors
    // Ep(0) = ref_state(0)-vec(0);
    // Ep(1) = ref_state(1)-vec(1);
    // if (Ep(1) < -M_PI){
    //     Ep(1) = Ep(1) + 2 * M_PI;
    // }
    Ep(0) = 0.0;
    Ep(1) = 0.0;
    Ep(2) = ref_state(2)-vec(2);
    
    // Velocity errors
    Ev(0) = ref_state(3)-vec(3);
    Ev(1) = ref_state(4)-vec(4);
    Ev(2) = ref_state(5)-vec(5);
    

    feedbck = Kv*Ev + Kp*Ep; 
    output_trq = E_h_inv*(M_h*(feedbck)+ H_h + V_h*velocities + G_h);

    
    CT_trq_r.data = output_trq(1); // Right wheel torque
    CT_trq_l.data = output_trq(0); // Left wheel torque
    
    
    Lwheel_pub.publish(CT_trq_l);
    Rwheel_pub.publish(CT_trq_r);

    Lknee_pub.publish(knee_ref);
    Rknee_pub.publish(knee_ref);
    Lhip_pub.publish(hip_ref);
    Rhip_pub.publish(hip_ref);

}// End of CT_controller

void igor_knee_control::ff_fb_controller(){
    ROS_INFO("In ff_fb control");
    //this->ref_update(); // calling the ref update function
    this->lqr_controller(igor_state);
    // this->CT_controller(igor_state);
    

    // Lwheel_pub.publish(trq_l);
    // Rwheel_pub.publish(trq_r);

}// End of ff_fb_controller


void igor_knee_control::ref_update()
{
    // ROS_INFO("In ref_update");
    mylock.lock();
    Kv(0,0) = -5.5;  //simulation for iros
    Kv(1,1) = -60.0; //simulation for iros
    Kp(0,0) = 0.0;   //simulation for iros
    Kp(1,1) = 0.0;   //simulation for iros
    // k_r(0,0) = k_l(0,0) = 0.0; // Forward position gain -ve
    // k_r(0,1) = k_l(0,1) = 0.0; // Yaw gain +ve
    // k_r(0,3)= k_l(0,3) = 0.90*(-4.8849);
    ref_state(3) = dwa_linear_velocity;
    ref_state(4) = dwa_angular_velocity;
    mylock.unlock();
    
}// End of ref_update function

igor_knee_control::~igor_knee_control()
{

} // End of destructor


int main(int argc, char **argv){
ros::init(argc, argv, "igor_controller"); // node name, can be superseded by node name in the launch file
ros::NodeHandle nh;
igor_knee_control myNode(&nh); // creating the igor_knee_control object
ros::Duration(0.1).sleep();
ros::MultiThreadedSpinner spinner(3); // Use 5 threads for 5 callbacks in parallel
spinner.spin(); // spin() will not return until the node has been shutdown
return 0;

} // end of main
